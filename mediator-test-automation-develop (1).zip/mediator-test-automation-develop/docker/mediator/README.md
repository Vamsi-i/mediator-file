# For tester

# Prerequisite : ICT version compatible:
ICT v0.13.0

##  to start the solution

```sh
make start --silent
```

## Stop all the env file

```sh
make stop --silent
```

# To create a delivery (Only at the end of sprint )

PS `This task need to be done after the end Sprint Demo`

- edit `.env` file

```env
...
sprint=mediator-sprint-XXX
```

- run delivery

```sh
make -j 10 delivery --silent
```
