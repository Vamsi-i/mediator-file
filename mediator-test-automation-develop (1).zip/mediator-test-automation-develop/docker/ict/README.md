# For tester

- to start the solution

```sh
make start --silent
```

## Access to application

- We can access to ICT using : `http://localhost:8282`

## Stop all the env file

```sh
make stop --silent
```

# To create a delivery (Only at the end of sprint )

PS `This task need to be done after the end Sprint Demo`

- edit `.env` file

```env
...
sprint=ict-sprint-XXX
```

- run delivery

```sh
make -j 10 delivery --silent
```
