// /// <reference types="cypress" />
// // ***********************************************************
// // This example plugins/index.js can be used to load plugins
// //
// // You can change the location of this file or turn off loading
// // the plugins file with the 'pluginsFile' configuration option.
// //
// // You can read more here:
// // https://on.cypress.io/plugins-guide
// // ***********************************************************

// // This function is called when a project is opened or re-opened (e.g. due to
// // the project's config changing)

// /**
//  * @type {Cypress.PluginConfig}
//  */
// // eslint-disable-next-line no-unused-vars
const cucumber = require("cypress-cucumber-preprocessor").default;
import { FilePath } from '../support/utils/config-utils/file-path';
const browserify = require("@cypress/browserify-preprocessor");
import { Reporter } from '../support/utils/reporter/report';
import { EnvironmentConfig } from '../support/utils/config-utils/test-management';
const xlsx = require('node-xlsx'); 
const fs = require('fs'); 
let testExecutionId;
const { isFileExist, findFiles } = require('cy-verify-downloads');

module.exports = (on) => {
  const options = {
    ...browserify.defaultOptions,
    typescript: require.resolve("typescript"),
  };

  on("file:preprocessor", cucumber(options));

  on('before:run', async (spec, results) => {
    fs.rmSync(FilePath.report, { recursive: true, force: true });
    testExecutionId = await EnvironmentConfig.setUpXray();
  });

  on('after:spec', async (spec, results) => {
    Reporter.publishReport();
    await EnvironmentConfig.tearDown(testExecutionId);
  });

  on('task', {
    parseXlsx({ file_path }) {
      return new Promise((resolve, reject) => {
        try {
          const jsonData = xlsx.parse(fs.readFileSync(file_path));
          resolve(jsonData);
        } catch (e) {
          reject(e);
        }
      });
    }
  });

  on("task", {
    dbQuery:(query)=> require("cypress-postgres")(query.query,query.connection)
  });

  on('task', { isFileExist, findFiles });
  
};