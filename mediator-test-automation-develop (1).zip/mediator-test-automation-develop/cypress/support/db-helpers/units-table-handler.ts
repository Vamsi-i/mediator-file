import { Config } from '../utils/config-utils/config';

export class UnitsTable {
  
  getDbData(instance_uuid:string) {
    const result: any = Config.getDatabaseConnection().then(function (connection: any) {
      return cy.task('dbQuery', { query: 'SELECT uuid FROM "instance" WHERE "gdmodelUuid" = \'' + instance_uuid + "'", connection: connection });    
    });
    return result;
  }; 

  getSettingUuidFromUnitsTable(target_instance_id:string, instance_uuid: string) {
    const result: any = Config.getDatabaseConnection().then(function (connection: any) {    
      return cy.task('dbQuery', { query: 'SELECT data FROM "units" WHERE "targetInstanceId" = \'' + target_instance_id + '\'AND "gdmodelUuid" = \'' + instance_uuid + "'" ,
      connection: connection });
    });
    return result;
  };

  getSettingDataFromUnitsTable(nodes_uuid:string) {
    const result: any = Config.getDatabaseConnection().then(function (connection: any) {
      return cy.task('dbQuery', { query: 'SELECT data FROM "units" WHERE "uuid" = \'' + nodes_uuid + "'", connection: connection });    
    });
    return result;
  };

  deleteAllUnits() {
    Config.getDatabaseConnection().then(function (connection) {
      return cy.task('dbQuery', { query: 'DELETE FROM "units"', connection: connection });
    });
  }

}
