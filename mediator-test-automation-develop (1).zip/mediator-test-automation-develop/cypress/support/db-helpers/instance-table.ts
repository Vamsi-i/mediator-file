import { Config } from '../utils/config-utils/config';

export class InstanceTable {

  deleteAllInstances() {
    Config.getDatabaseConnection().then(function (connection) {
      return cy.task('dbQuery', { query: 'DELETE FROM "instance"', connection: connection });
    });
  }
  
}