import { Config } from '../utils/config-utils/config';

export class WorkspaceTable {

  deleteAllWorkSpace() {
    Config.getDatabaseConnection().then(function (connection) {
      return cy.task('dbQuery', { query: 'DELETE FROM "workspace"', connection: connection });
    });
  }

}

