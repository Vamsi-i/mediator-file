
import { UIHandler } from '../utils/ui-utils/cypress-util';


export class DeviceSettingsNetworkPage extends UIHandler {

  private device_list = '[role="treeitem"].mat-tree-node';
  private settings_tab = 'Settings';
  private network_link = 'a:contains("Network")';
  //private settings_sub_function_tab = '//a[@class="cdk-drag mat-tab-link mat-focus-indicator ng-star-inserted"]';
  private settings_sub_function_tab = 'a.cdk-drag.mat-tab-link.mat-tab-label-active';
  private alias_tcp_ip = '(//input[@class="gadm-ag-grid-text-cell gadm-text-input"])[1]';
  private network_tab_close = '//div[@class="gx-close-container ng-star-inserted"]';
  private device_close_button = '.close > svg';
  private inputs_link = '(//*[@class="w-100 ng-star-inserted"])[2]';
  private add_phase_a_array = '//*[@class="node__children ng-star-inserted"]/*';
  
  
  protected verifyAliasTCPIP() {
    this.getElement(this.device_list).each(($ele) => {
      let device_name = $ele.text().trim().split('airplay')[1];
      this.clickElement(device_name, 'contains');
      this.clickElement(this.settings_tab, 'contains');
      this.clickElement(this.network_link);
      //this.clickElement(this.settings_sub_function_tab, 'xpath');
      this.clickElement(this.settings_sub_function_tab);
      this.getElement(this.alias_tcp_ip, 'xpath').should('have.value', device_name);
      this.clickElement(this.network_tab_close, 'xpath');
      this.clickElement(this.device_close_button);
    });
  }

  protected openSubFunctionscreen(function_name: string) {
    this.clickElement(this.settings_tab, 'contains');
    cy.wait(3000) // this wait is required for setting load
    this.clickElement(function_name, 'contains');
    cy.wait(3000) // this wait is required for setting load
    //this.clickElement(this.settings_sub_function_tab, 'xpath');
    this.clickElement(this.settings_sub_function_tab);
  }
  protected openInputstab() {
      this.clickElement(this.inputs_link, 'xpath');
  }
  protected navigateDataPoint(data_point: string) {
      this.clickHiddenElement(data_point, 'contains');
  }
  protected verifyListOfDatapoints() {
      return this.getList(this.add_phase_a_array);
  }
  protected getList(element_locator: string) {
      let list: any =[];
      this.getElement(element_locator, 'xpath').each((ele) => {
        //cy.log(ele.text().trim());
        list.push(ele.text().trim());
      });
      return list;
  }
  protected clickADataPoint(data_point: string) {
    this.isEnabled(data_point, 'contains');
    this.clickHiddenElement(data_point, 'contains');
  }

}



