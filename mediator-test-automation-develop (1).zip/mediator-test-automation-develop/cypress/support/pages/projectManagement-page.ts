
import { UIHandler } from '../utils/ui-utils/cypress-util';
const wait = Cypress.env('wait')!;
/// <reference types="Cypress" />
export class ProjectManagementPage extends UIHandler {
  
  private mediator_project_import_btn = '.mat-card-title > div > button.mat-focus-indicator > .mat-button-wrapper > .px > svg';      
  private project  = '//table/tbody/tr/td/a[contains(text(),"**{projectName}**")]';
  private open_project = '.mat-menu-content > :nth-child(1)';
  //private checklabel: string = '//*[contains(text(),"Please add or select an element/device to configure")]'
  private device_list = '[role="treeitem"].mat-tree-node';
  private project_anagement_page_text = 'span:contains("Project Management")';
  private name_text_field = '#mat-input-1';
  private description_text_field = '#mat-input-2';
  private create_project_button = '[type="submit"] > .mat-button-wrapper';
  private plus_icon ='.mat-card-title > div > button.mat-focus-indicator > .mat-button-wrapper > .polaris > svg';
  private Project_name_column = 'table > tbody > tr > td[role="gridcell"]:nth-child(1)';
  private edit_project = '.mat-menu-content > :nth-child(3)';
  private delete_project = '.mat-grid-tile-footer > [style="display: flex; align-items: center; width: 100%;"] > .mat-focus-indicator';
  private confirm_delete_project = '.mat-dialog-actions > .mat-primary';
  private logOut = ' logout ';
  private user_action = 'gx-icon[class="mat-menu-trigger quickAction px ng-star-inserted"]';
    
  protected clickPlusIcon() {    
    this.scrollIntoView(this.plus_icon);
    this.clickElement(this.plus_icon);
  }

  protected clickUserAction() {
    this.clickElement(this.user_action);
  }

  protected clickOnLogout() {
    this.clickElement(this.logOut, 'contains');
  }

  protected enterProjectName(project_name: string){
    this.enterText(this.name_text_field, project_name);
  }

  protected enterProjectDescriptio(project_des: string){
    this.enterText(this.description_text_field, project_des);
  }

  protected clickCreateProject() {    
   this.clickElement(this.create_project_button);
  }

  protected clickActionCellAsPerProjectName(project_name: string) {
    this.refreshPage();    
    this.getElement(this.Project_name_column).each(function($ele, index) {
      if($ele.text().trim()== project_name) {     
        cy.get(`tr:nth-child(${index+1}) > td:nth-child(4)`).click();               
      }
    });
  }

  protected editProjectButton(){
    this.isElementPresent(this.edit_project);  
    this.clickElement(this.edit_project);
  }

  protected delectProjectButton(){
    this.isElementPresent(this.delete_project);  
    this.clickElement(this.delete_project);
  }

  protected ConfirmDeleteProjectDialog(){
    this.isElementPresent(this.confirm_delete_project);  
    this.clickElement(this.confirm_delete_project);
  } 
  
  protected verifyMediatorScdImportBtn(){
    cy.get(this.mediator_project_import_btn, {timeout: wait.minWait}).should('exist');    
  }

  protected clickMediatorScdImportBtn(){
    this.clickElement(this.mediator_project_import_btn);    
  }

  protected isProjectPresent(p_name: string) {   
    cy.wait(3000);
    cy.reload();    
    cy.xpath(this.project.replace('**{projectName}**', ' ' + p_name.toString() + ' '), {timeout: wait.maxWait}).should('be.visible');        
  }

  protected clickProjectButton() {
    this.isElementPresent(this.open_project);  
    this.clickElement(this.open_project);    
    cy.get(this.device_list, {timeout: wait.maxWait}).should('exist');
  }

  protected clickOnActionCell(element_locator: string, value: string, element_type?: string) {
    this.getElement(element_locator,element_type).each(function($ele, index) {
      if($ele.text().trim()== value) {     
        cy.get(`tr:nth-child(${index+1}) > td:nth-child(4)`).click();               
      }
    });
  }

  protected selectProjectFromListOfProjects(element_locator: string, value: string, element_type?: string) {
    this.getElement(element_locator,element_type).each(function($ele) {
      if($ele.text().trim()== value) {
        cy.wrap($ele).click();
      }
    }); 
  }
  
}
