
import { UIHandler } from '../utils/ui-utils/cypress-util';

/// <reference types="Cypress" />
export class DeviceProfilePage extends UIHandler {

  private device_gdsl_version = '//div[contains(text(),"GDSL Version")]/following-sibling::div';
  private device_asset_id = '//div[contains(text(),"Asset ID")]/following-sibling::div';
  
  protected getGdslVersion() {
    return this.getText(this.device_gdsl_version,'xpath' ).then((value:string)=>{
      cy.log(value);    
    }); 
  }

  protected getUuid() {
    return this.getText(this.device_asset_id,'xpath' ).then((value:string)=>{
      cy.log(value);    
    }); 
  }
}
