
import { UIHandler } from '../utils/ui-utils/cypress-util';
const wait = Cypress.env('wait')!;

/// <reference types="Cypress" />
export class AddDevicePage extends UIHandler {

  private device_name_txt = '#mat-input-4';
  private iec_name_txt = '#mat-input-5';
  private device_type_cmb_icon = '#mat-select-2 > .mat-select-trigger > .mat-select-arrow-wrapper'
  private device_type = '#mat-select-2'
  private device_type_lst = '[id*="mat-option"] span'
  private version_cmb_icon ='#mat-select-4 > div > div.mat-select-arrow-wrapper'
  private version = '[id*="mat-option"] span';
  private create_device_btn = '[type="submit"]';
  private close_device_icon = 'a:nth-child(2) > gx-icon';
  private toolbar = 'body > gadm-layout > mat-toolbar';
  private device_list = '[role="treeitem"].mat-tree-node';

  protected enterDeviceName(device_name:string) {
    this.isElementPresent(this.device_name_txt);
    this.enterText(this.device_name_txt,device_name)
  }

  protected enterIecName(iec_name:string) {
    this.isElementPresent(this.iec_name_txt);
    this.enterText(this.iec_name_txt, iec_name);
  }

  protected selectDeviceType(deviceType:string) {
    this.isElementPresent(this.device_type);
    this.clickElement(this.device_type_cmb_icon);
    this.selectValueFromBootstrapDropdown(this.device_type_lst, deviceType);    
  }

  protected selectVersion(version:string) {
    this.isElementPresent(this.version_cmb_icon);
    this.clickElement(this.version_cmb_icon);
    this.selectValueFromBootstrapDropdown(this.version, version);
  }

  protected clickCreateDeviceButton(device_name: string) {
    this.isElementPresent(this.create_device_btn);
    this.clickElement(this.create_device_btn);
    this.waitUntil(this.device_list, wait.maxWait ,'visible');    
    //cy.get(this.device_list, { timeout: wait.maxWait }).should('be.visible');
    this.verifyDeviceNameAfterCreate(this.device_list,device_name)
  }

  protected closeDevice() {
    this.checkIfEleExistsThenClick(this.toolbar,this.close_device_icon)
  }

   // click dropdown before calling this method
  protected selectValueFromBootstrapDropdown(element_locator: string, value: string, element_type?: string){
    this.getElement(element_locator,element_type).each(function($ele) {
      if($ele.text().trim()== value){
        cy.wrap($ele).click();
      }
    });
  }

  protected verifyDeviceNameAfterCreate(element_locator: string, value: string, element_type?: string) {    
    this.getElement(element_locator,element_type).each(function($ele) {      
      if($ele.text().trim().includes(value)) {   
        expect($ele.text().trim().includes(value));                               
      }     
    });      
  }
 
}
