
import { UIHandler } from '../utils/ui-utils/cypress-util';


export class DeviceSettingsUserDataPage extends UIHandler {

    private extref_array = '.mat-tree mat-tree-node[role="treeitem"]';
    private settings_tab = 'Settings';
  
    protected openUserDatascreen(function_name: string) {
        this.clickElement(this.settings_tab, 'contains');
        this.clickElement(function_name, 'contains');        
    }
    
    protected verifyListOfExtrefDatapoints() {
        this.isElementPresent(this.extref_array)
      return this.getList(this.extref_array);
    }
    protected getList(element_locator: string) {
      let list: any =[];
      this.getElement(element_locator).each((ele) => {
        //cy.log(ele.text().trim());
        list.push(ele.text().trim());
      });
      return list;
    }
}



