import { UIHandler } from "../utils/ui-utils/cypress-util";
const wait = Cypress.env('wait')!;

/// <reference types="Cypress" />

export class MediatorSettingImportPage extends UIHandler {
    //private setting_import_button: string = '//*[contains(text(),"RTE settings import")]';
    private setting_import_button = '.mat-menu-content > .ng-star-inserted > span';    
    private uuid_link = 'app-instance-selector > div > div > a';
    private import_file = 'div.input-file input[type="file"]';
    private import_selection = '//*[contains(text(),"Import Selection")]';
    private grid = 'ag-grid-angular.ag-theme-balham-dark';
    private next_button = '.mediator-import-settings-actions-btns > button:nth-child(2)';
    private finish_button = '.mediator-import-settings-actions-btns > button';
    private loading_overlay = '.ag-overlay-loading-center';
    private table_rows = 'div[class="ag-center-cols-viewport"] div[role="rowgroup"]';
    private table = 'div.ag-body-viewport';
    private error_message = '.message';
    private export = '[aria-expanded="false"] > .ag-menu-option-text';
    private cancel_btn = 'Cancel';
    private csv_export: string = 'div[ aria-label="SubMenu"] .ag-menu-list div[role="treeitem"] span.ag-menu-option-text:contains("CSV Export")';
    //private csv_export = 'CSV Export';
   // private excel_export: string = 'div[ aria-label="SubMenu"] .ag-menu-list div[role="treeitem"] span:contains("Excel Export")';
    private excel_export = 'div[ aria-label="SubMenu"] .ag-menu-list div[role="treeitem"] span.ag-menu-option-text:contains("Excel Export")';
    
    protected clickSettingImportButton() {
        this.clickElement(this.setting_import_button);
    }

    protected verifySettingImportButton() {
        this.isElementPresent(this.setting_import_button);
    }

    protected selectUuidLink() {
        this.clickElement(this.uuid_link);
    }

    protected uploadFile(file: string) {
        //this.isDisabled(this.import_selection, 'xpath');
        this.verifyImportSelectionButton();
        this.attachFile(this.import_file,file);
    }

    protected clickImportSelection() {        
        this.clickElement(this.import_selection,'xpath'); 
    }

    protected verifyMediatorGrid() {
        this.waitUntil(this.grid, wait.maxWait ,'visible'); 
    }

    protected clickOnNextButton() {
        this.clickElement(this.next_button);
    }

    protected clickOnFinishButton() {
        this.clickElement(this.finish_button);
    }   
    
    protected checkNextBtnEnableState() {
        this.isDisabled(this.next_button);
    }

    protected verifyNextBtn() {
        this.waitUntil(this.next_button, wait.maxWait ,'not_exist'); 
        cy.wait(500) // this wait is require to update database with imported values.
    }

    protected verifyOverlay() {
        this.waitUntil(this.loading_overlay, wait.maxWait ,'not_exist');      
    }
    
    protected getDataFromMediatorSettingGrid (scroll_position: any,col_name1: string, col_name2: string) {
        this.getElement(this.table).scrollTo(scroll_position);
        cy.wait(1000); // this wait is require to refresh table while scrolling
         //return this.getTableMultipleCellValuesInArray(this.table_rows,'div[role="row"]','div[col-id="id"]', 'div[col-id="newValue"]');
        return this.getTableMultipleCellValuesInArray(this.table_rows,'div[role="row"]','div[col-id=' + col_name1 + ']', 'div[col-id=' + col_name2 + ']');
    };

    protected getDataFromMediatorSettingGridFromThreeCols (scroll_position: any,col_name1: string, col_name2: string, col_name3: string) {
        this.getElement(this.table).scrollTo(scroll_position);
        cy.wait(1000); // this wait is require to refresh table while scrolling        
        return this.getThreeCellValuesInArray(this.table_rows,'div[role="row"]','div[col-id=' + col_name1 + ']',
         'div[col-id=' + col_name2 + ']', 'div[col-id=' + col_name3 + ']');
    };

    protected getDataFromMediatorSettingGridFromFourCols (scroll_position: any,col_name1: string,
       col_name2: string, col_name3: string, col_name4: string) {
      this.getElement(this.table).scrollTo(scroll_position);
      cy.wait(1000); // this wait is require to refresh table while scrolling        
      return this.getFourCellValuesInArray(this.table_rows,'div[role="row"]','div[col-id=' + col_name1 + ']',
       'div[col-id=' + col_name2 + ']', 'div[col-id=' + col_name3 + ']', 'div[col-id=' + col_name4 + ']');
  };

    protected verifyErrorMgs() {
        this.waitUntilTextMatch(this.error_message, wait.minWait,'contain','Error was occured while importing')
        //cy.get(this.error_message, {timeout: wait.minWait}).should('contain','Error was occured while importing');      
    }

    protected verifyImportSelectionButton() {
        this.isDisabled(this.import_selection, 'xpath');
    }

    protected clcikCancelBtn() {
        this.getElement(this.cancel_btn, 'contains').click()
    }

    protected exportCSV() {
        this.getElement(this.table).rightclick();  
        this.waitUntil(this.export, wait.maxWait,'visible');
        this.getElement(this.export).click({ force: true }); 
        this.waitUntil(this.csv_export, wait.maxWait,'visible');
        this.getElement(this.csv_export).click({ force: true });      
    }

    protected exportExcel() {
        this.getElement(this.table).rightclick();
        this.waitUntil(this.export, wait.maxWait,'visible');
        this.getElement(this.export).click({ force: true });
        this.waitUntil(this.excel_export, wait.maxWait,'visible');      
        this.getElement(this.excel_export).click({ force: true });    
    }

    protected getTableMultipleCellValuesInArray(base_locator: string, row_element: string, cell_1_element: string ,
        cell_2_element: string, element_type?: string): Promise<any> {
        const cell_1_data: any[] = [];
        const cell_2_data: any[] = [];
        const table_data_object = {};
        return new Promise<any> ((resolve, reject) =>{
          this.findElement(base_locator, row_element, element_type).each(($row) => {
            cell_1_data.push($row.children(cell_1_element).text().toString());        
            cell_2_data.push($row.children(cell_2_element).text().toString());
    
            cell_1_data.forEach(function (k: any, i: any) {
              table_data_object[k] = cell_2_data[i];
            });
    
            if (table_data_object) {          
              resolve(table_data_object);
            } else reject();
    
          });
        });
      }

      protected getThreeCellValuesInArray(base_locator: string, row_element: string, cell_1_element: string ,
        cell_2_element: string, cell_3_element: string, element_type?: string): Promise<any> {
        const cell_1_data: any[] = [];
        const cell_2_data: any[] = [];
        const cell_3_data: any[] = [];
        const table_data_object = {};
        return new Promise<any> ((resolve, reject) =>{
          this.findElement(base_locator, row_element, element_type).each(($row) => {
            cell_1_data.push($row.children(cell_1_element).text().toString());        
            cell_2_data.push($row.children(cell_2_element).text().toString());
            cell_3_data.push($row.children(cell_3_element).text().toString());
    
            cell_1_data.forEach(function (k: any, i: any) {
              table_data_object[k] = cell_2_data[i] + ':' + cell_3_data[i];
            });
    
            if (table_data_object) {          
              resolve(table_data_object);
            } else reject();
    
          });
        });
      }

      protected getFourCellValuesInArray(base_locator: string, row_element: string, cell_1_element: string ,
        cell_2_element: string, cell_3_element: string, cell_4_element: string, element_type?: string): Promise<any> {
        const cell_1_data: any[] = [];
        const cell_2_data: any[] = [];
        const cell_3_data: any[] = [];
        const cell_4_data: any[] = [];
        const table_data_object = {};
        return new Promise<any> ((resolve, reject) =>{
          this.findElement(base_locator, row_element, element_type).each(($row) => {
            cell_1_data.push($row.children(cell_1_element).text().toString());        
            cell_2_data.push($row.children(cell_2_element).text().toString());
            cell_3_data.push($row.children(cell_3_element).text().toString());
            cell_4_data.push($row.children(cell_4_element).text().toString());
    
            cell_1_data.forEach(function (k: any, i: any) {
              table_data_object[k] = cell_2_data[i] + ':' + cell_3_data[i] + ':' + cell_4_data[i];
            });
    
            if (table_data_object) {          
              resolve(table_data_object);
            } else reject();
    
          });
        });
      }

}