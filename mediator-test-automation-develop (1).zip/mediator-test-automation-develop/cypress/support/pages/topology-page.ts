
import cypress from 'cypress';
import { UIHandler } from '../utils/ui-utils/cypress-util';
import { AddDevicePage } from './add-device-page';
/// <reference types="Cypress" />
const wait = Cypress.env('wait')!;

const addDevicePageHelperObj: AddDevicePage = new AddDevicePage();

export class TopologyPage extends UIHandler {
 
  private project_header = '.nav-bar-title';
  private add_device_icon = '.mat-card-title .mat-icon-button gx-icon.polaris > svg';
  private create_device_button = 'Add Device';
  private close_topology_view_icon = '.mat-icon > svg';
  private close_project_btn_in_dialog ='button.mat-focus-indicator.mat-raised-button.mat-button-base.mat-primary'
  private device_link = '.tree-node-label-link';
  private send_button = 'Send';
  private ok_file_transfer_dig = '.mat-dialog-container .mat-dialog-actions button.mat-primary';
  private file_transfer_details_col = '.cdk-table  tbody  tr  td:nth-child(3)';
  private items_per_page_cmb ='[id*="mat-option"] span';
  private items_per_page_cmb_arrow ='.mat-select-trigger .mat-select-arrow-wrapper';
  private items_per_page_lb = 'Items per page:'

  protected validateProjectTitle(){
    this.isElementPresent(this.project_header);    
  }

  protected clickAddDeviceIcon() {    
    this.clickElement(this.add_device_icon);
  }

  protected clickCreateDeviceButton() {    
    this.clickElement(this.create_device_button, 'contains');
  }

  protected closeTopologyView() {
    this.refreshPage();
    if (this.isElementPresent(this.close_topology_view_icon)){
      this.clickElement(this.close_topology_view_icon);
      this.clickElement(this.close_project_btn_in_dialog);
    };    
  }

  protected clickOnDeviceName() {
    this.isElementPresent(this.device_link);
    this.clickElement(this.device_link);
  }
  
  protected clickSendButton() {
    this.isElementPresent(this.send_button, 'contains');
    this.clickElement(this.send_button, 'contains');
  }

  protected clickOkOnFileTransferDlg() {
    this.isElementPresent(this.ok_file_transfer_dig);
    this.clickElement(this.ok_file_transfer_dig);
          
  }

  protected selecItemsPerPage() {
    this.scrollIntoView(this.items_per_page_lb,'contains');
    this.clickElement(this.items_per_page_cmb_arrow);
    this.getElement(this.items_per_page_cmb).each(function($ele) {
      if($ele.text().trim() == '10'){
        cy.wrap($ele).click({force:true});
      }
    });     
  }

  protected getDetailsFromFileTransferTable(): Promise <any> {
    let details : any [] = [];
    return new Promise <any> ((resolve, reject) => {
      this.isElementPresent(this.file_transfer_details_col);
      cy.get(this.file_transfer_details_col, {timeout: wait.maxWait}).should('have.length', 9)
      cy.wait(2000); // this wait is required to get data from table
      this.getElement(this.file_transfer_details_col).each(function($ele, index) {
        details.push($ele.text().trim());
        //cy.log($ele.text().trim());
        if (details) {          
          resolve(details);
        } else reject();      
      });
    });
    
  } 

}
