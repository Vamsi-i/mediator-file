import { UIHandler } from '../utils/ui-utils/cypress-util';
/// <reference types="Cypress" />
import { assert } from 'chai';
const wait = Cypress.env('wait')!;

export class LoginPage extends UIHandler {
  private signin_btn = 'span:contains(" SIGN IN ")';
  private username = '#mat-input-0';
  private password = '#mat-input-1';
  private connect_with_account = 'button.mat-focus-indicator.mat-flat-button.mat-button-base.mat-primary'
  private home_page_header ='.navbar-image';

  protected launchUrl(url: string) {
    try {
      return this.launchWebSite(url);
    } catch (error) {
      cy.log(error);
      assert.fail();
    }
  }

  protected enterUserName(credential: string) {
    this.enterText(this.username, credential.split(',')[0]);
  }

  protected enterpassword(credential: string) {
    this.enterText(this.password, credential.split(',')[1]);
  }

  protected homePageVerification() {
      cy.get(this.home_page_header, {timeout: wait.maxWait}).should('exist');
  }

  protected clickSignIn() {
    this.clickElement(this.signin_btn);
  }

  protected clickConnect() {
    this.clickElement(this.connect_with_account);
  }
}
