import { contains } from 'cypress/types/jquery';
import { UIHandler } from '../utils/ui-utils/cypress-util';
const wait = Cypress.env('wait')!;
/// <reference types="Cypress" />
export class MediatorScdImportPage extends UIHandler {
  private scd_import_button: string = '[href="/project-plugin"]';
  private import_file: string = 'div.input-file input[type="file"]';
  private import_selection: string = '//*[contains(text(),"Import Selection")]';
  private cancel: string = 'lib-mediator-project-plugin .mat-raised-button:nth-child(1)';
  private ge_devices_list: string = 'lib-mediator-import-content-scd > div > mat-card > lib-selection-list:nth-child(1) > mat-selection-list';
  private ge_device: string = '[aria-selected="true"]';
  private ge_project_lable: string = '//*[contains(text(),"Project Devices")]';
  private third_party_devices_list: string =
    'lib-mediator-import-content-scd > div > mat-card > lib-selection-list:nth-child(2) > mat-selection-list';
  private third_party_device: string = '[aria-selected="false"]';
  private third_party_project_lable: string = '//*[contains(text(),"Third Party Devices")]';
  private ge_selected_devices: string = '.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled';
  private third_party_unselected_devices: string = '.mat-pseudo-checkbox.ng-star-inserted';
  //private error_dialog: string = '#cdk-overlay-11 .mat-dialog-actions > button';
  private error_dialog: string = '.mat-dialog-actions > .mat-focus-indicator';
  //private project_management_screen = 'span:contains("Project Management")';
  private project_management_screen = 'span.fixed-title';

  protected clickScdImportButton() {
    this.clickElement(this.scd_import_button);
  }

  protected verifyScdImportButton() {
    this.isElementPresent(this.scd_import_button);
  }

  protected uploadFile(file: string) {
    this.verifyImportSelectionButton();
    this.attachFile(this.import_file, file);
  }

  protected verifyImportSelectionButton() {
    this.isDisabled(this.import_selection, 'xpath');
  }

  protected clickOnImportSelectionButton() {
    this.clickElement(this.import_selection, 'xpath');
    // need to remove belowasync method once scd import issue fixed
    this.waitForAsyncCalls(
      this.checkIfElementExists,
      'Waiting for expected error dialog for SCD import...',      
      this.error_dialog
    );
    this.clickElement(this.error_dialog);
    this.waitForAsyncCalls(
      this.checkIfElementExists,
      'Waiting for the project creation...',
        //this.validation_error,
      //this.device_created_check.replace('**device**', device_name)
      this.project_management_screen
    );
  }

  protected verifyGeDeviceList() {
    cy.get(this.ge_devices_list, { timeout: wait.maxWait }).should('exist');
    this.isElementPresent(this.ge_project_lable, 'xpath');
  }

  protected GeDevicesSelectedList() {
    return this.getCheckBoxList(this.ge_devices_list, this.ge_selected_devices);
  }

  protected ThirdPartyUnselectedDevicesList() {
    return this.getCheckBoxList(this.third_party_devices_list, this.third_party_unselected_devices);
  }

  protected getCheckBoxList(parent_locator: string, element_locator: string) {
    let checkBoxlist: any[] = [];
    this.findElement(parent_locator, element_locator).each((device) => {
      //cy.log(device);
      checkBoxlist.push(device);
    });
    return checkBoxlist;
  }

  protected geDevicesList() {
    return this.getList(this.ge_devices_list, this.ge_device);
  }

  protected verifyThirdPartyDeviceList() {
    cy.get(this.third_party_devices_list, { timeout: wait.maxWait }).should('exist');
    this.isElementPresent(this.third_party_project_lable, 'xpath');
  }

  protected ThirdPartyDevicesList() {
    return this.getList(this.third_party_devices_list, this.third_party_device);
  }

  protected clickOnOkInErrorDialog() {
    cy.get(this.error_dialog, { timeout: wait.maxWait }).should('exist');
    this.clickElement(this.error_dialog);
    //this.clickElement(this.ok_button_validation_popup);
  }

  protected getList(parent_locator: string, element_locator: string) {
    let list: any[] = [];
    this.findElement(parent_locator, element_locator).each((device) => {
      //cy.log(device.text().trim());
      list.push(device.text().trim());
    });
    return list;
  }
  protected closeScdImportDialog() {
    this.clickElement(this.cancel);
  }


}
