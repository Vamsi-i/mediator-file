
import { UIHandler } from '../utils/ui-utils/cypress-util';
/// <reference types="Cypress" />

export class DeviceManagementPage extends UIHandler {

  private device_list = '[role="treeitem"].mat-tree-node';
  private three_dots = '.mat-tree-node > .mat-menu-trigger';
  private IEC_61850 = '//span[contains(text(),"IEC 61850")]';
  private third_party_devices_list = '//*[contains(text(),"Third Party Devices")]/following-sibling::div';
  private third_party_device = '.link';
  
  
  protected clickOnDeviceIconFromList(device_name: string ) {
    this.isElementPresent(this.device_list);
    this.clickOnDeviceIcon(this.device_list, device_name)
  }

  protected verifyingThreeDotsMenu() {
    this.isElementPresent(this.three_dots);    
  }

  protected clickOnThreeDotsMenu() {
    this.clickElement(this.three_dots);
  }

  protected async getDeviceListInProject() {     
    const device_list: any[] = [];    
    this.getElement(this.device_list).each(function($ele) {
      //cy.log($ele.text().trim().split('airplay')[1]);
      device_list.push($ele.text().trim().split('airplay')[1]);
    });
    return device_list;    
    
    //return this.getListOfDevices(this.device_list);
  }  

  protected clickOnDeviceIcon(element_locator: string, value: string, element_type?: string) {
    this.getElement(element_locator,element_type).each(function($ele, index) {
      if($ele.text().trim().includes(value)) {
        //this.getElement(`:nth-child(${index+1}) > .mat-tree-node > .w-100 > .mat-focus-indicator`).click(); 
        cy.get(`:nth-child(${index+1}) > .mat-tree-node > .w-100 > .mat-focus-indicator`).click();                      
      }
    });
  }

  protected clickOnDeviceName(device_name: string) {
    //this.getElement(device_name, 'contains');
    this.clickElement(device_name, 'contains');
  }
  protected clickOnIEC61850() {
    this.clickElement(this.IEC_61850, 'xpath');
    this.getElement(this.third_party_devices_list, 'xpath').should('exist');
  }

  protected thirdPartyDevicesInIEC61850() {
    let list: any[] = [];
    this.findElement(this.third_party_devices_list, this.third_party_device, 'xpath').each((device) => {
      list.push(device.text().trim());
    });
    return list;
  }

}



