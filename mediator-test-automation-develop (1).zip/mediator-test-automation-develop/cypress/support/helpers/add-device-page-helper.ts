import { AddDevicePage } from '../pages/add-device-page';

export class AddDevicePageHelper extends AddDevicePage {

  public addDevice(device_name:string, iec_name:string, device_type:string, version:string) {
    this.enterDeviceName(device_name);
    this.enterIecName(iec_name);
    this.selectDeviceType(device_type);
    this.selectVersion(version);
    this.clickCreateDeviceButton(device_name);
  }

  public close_Device() {
    this.closeDevice();
  }
}
