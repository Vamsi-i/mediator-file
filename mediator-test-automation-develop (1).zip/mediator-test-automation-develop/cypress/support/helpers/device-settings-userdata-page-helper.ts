import { DeviceSettingsUserDataPage } from "../pages/device-settings-userdata-page";

export class DeviceSettingsUserDataHelper extends DeviceSettingsUserDataPage {

    public getListOfExtRefDatapoints() {   
        //cy.log('this tes' + this.verifyListOfExtrefDatapoints());
        return this.verifyListOfExtrefDatapoints();       
    }    

    public goToUserDataPage(func_name: any) {
        this.openUserDatascreen(func_name)
    }
}