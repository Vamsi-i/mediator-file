import { DeviceSettingsNetworkPage } from "../pages/device-settings-network-page";

export class DeviceSettingsNetworkHelper extends DeviceSettingsNetworkPage {

    public verifyAliasTCPIPfield() {
        this.verifyAliasTCPIP();
    }

    public goToSettingsSubFunction(funct_name: string) {
        this.openSubFunctionscreen(funct_name);
    }
    public goToInputs() {
        this.openInputstab();
    }
    public goToDataPoint(datapoint_name: string) {
        this.navigateDataPoint(datapoint_name);
    }
    public getListOfDatapoints() {
        return new Promise<any>((resolve, reject) => {
            resolve(this.verifyListOfDatapoints());
        })
    }
    public selectADataPoint(name: string) {
        this.clickADataPoint(name);
    }
   
}