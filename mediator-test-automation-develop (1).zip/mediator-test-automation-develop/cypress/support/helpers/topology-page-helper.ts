import { TopologyPage } from '../pages/topology-page';

export class TopologyPageHelper extends TopologyPage {

  public selectAddDevice() {
    //this.validateProjectTitle();
    this.clickAddDeviceIcon();
    this.clickCreateDeviceButton();
  }

  public closeTopology() {   
    this.closeTopologyView();    
  }

  public goToDeviceView() {
    this.clickOnDeviceName();
  }

  public clickOnSend() {
    this.selecItemsPerPage();
    this.clickSendButton();
    this.clickOkOnFileTransferDlg();    
  }

  public getDetailsFromGenerationTable() {
    return this.getDetailsFromFileTransferTable();
  }
  
}
