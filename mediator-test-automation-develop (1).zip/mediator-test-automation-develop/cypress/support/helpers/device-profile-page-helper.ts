import { DeviceProfilePage } from '../pages/device-profile-page'

export class DeviceProfilePageHelper extends DeviceProfilePage {

  public getDeviceGdslVersion() {
    return this.getGdslVersion();
  }

  public getAssetID() {
    return this.getUuid(
      
    );
  }
}
