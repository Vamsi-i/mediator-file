import { throws } from 'assert';
import { LoginPage } from '../pages/login-page';

export class LoginPageHelper extends LoginPage {

  public loginToIct(url: string, credential: string) {
    this.launchWebPage(url);
    this.clickConnect();
    this.enterUserName(credential);
    this.enterpassword(credential);
    this.clickSignIn();
    this.homePageVerification()    
  }

  // not required below method as we can call 'launchUrl' method directly
  public launchWebPage(url: string) {
    cy.log('test running');
    this.launchUrl(url);
  }
}
