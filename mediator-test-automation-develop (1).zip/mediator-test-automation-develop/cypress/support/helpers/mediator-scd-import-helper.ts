import { MediatorScdImportPage } from "../pages/mediator-scd-import-page";

export class MediatorScdImportHelper extends MediatorScdImportPage {

    public clickOnScdImportButton() {
        this.clickScdImportButton();
    }
    
    public verifyScdImportBtn() {
        this.verifyScdImportButton();
    }

    public uploadScdFile(file: string) {
        this.uploadFile(file);
    }

    public getListOfDevicesFromMediator() {
        return this.geDevicesList();
    }

    public checkingGeDeviceList() {
        this.verifyGeDeviceList();              
    }

    public getListOfThirdPartyDevices() {
        return this.ThirdPartyDevicesList();
    }

    public checkingThirdPartyDeviceList() {
        this.verifyThirdPartyDeviceList();              
    }

    public verifyImportSelection() {
        this.verifyImportSelectionButton();
    }

    public getSelectedDeviceByDefault() {       
        return this.GeDevicesSelectedList();
    }

    public thirdPartyUnselectedDevicesByDefault() {
        return this.ThirdPartyUnselectedDevicesList();
    }

    public clickImportSelectionBtn() {
        this.clickOnImportSelectionButton();
    }

    public clickOkInError() {
        this.clickOnOkInErrorDialog();
    }

    public closeScdImportdia() {
        this.closeScdImportDialog();
    }

   
}