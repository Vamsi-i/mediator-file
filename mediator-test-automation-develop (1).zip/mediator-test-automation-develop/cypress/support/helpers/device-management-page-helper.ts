import { DeviceManagementPage } from '../pages/device-management-page';

export class DeviceManagementPageHelper extends DeviceManagementPage {

 public clickOnDeviceIconInList(device_name: string) {  
  this.clickOnDeviceIconFromList(device_name); 
  this.verifyingThreeDotsMenu();  
 }

 public clickOnthreeDotsIcon(){
  this.clickOnThreeDotsMenu();
 }

 public async getDeviceListInOneProject() {
     return this.getDeviceListInProject();
 }

 public goToIEC61850(device_name: string) {
    this.goToDeviceView(device_name);
    this.clickOnIEC61850();
 }
 public goToDeviceView(device_name:string) {
   this.clickOnDeviceName(device_name);
 }

 public getThirdPartyDevicesInIEC61850() {
    return this.thirdPartyDevicesInIEC61850();
 }

 

}
