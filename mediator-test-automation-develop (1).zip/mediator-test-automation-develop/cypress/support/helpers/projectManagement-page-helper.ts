import { ProjectManagementPage } from '../pages/projectManagement-page';

export class ProjectManagementPageHelper extends ProjectManagementPage {

  public logOutICTApp() {
    this.clickUserAction();
    this.clickOnLogout();
  }
  public createProject(project_name:string, project_des:string){
    this.validateClickingPlusIcon();
    this.enterProjectNameInTextbox(project_name);
    this.enterProjectDescriptionInTextbox(project_des);
    this.clickingCreateProjectButton();
  }

  public validateClickingPlusIcon() {
    this.clickPlusIcon();
  }

  public enterProjectNameInTextbox(project_name: string) {
    this.enterProjectName(project_name);
  }

  public enterProjectDescriptionInTextbox(project_desc: string) {
    this.enterProjectDescriptio(project_desc);
  }

  public clickingCreateProjectButton() {
    this.clickCreateProject();
  }

  public delectProject(project_name: string) {
    this.clickActionCellAsPerProjectName(project_name);
    this.editProjectButton();
    this.delectProjectButton();
    this.ConfirmDeleteProjectDialog();
  }

  public checkMediatorProjectImportBtn() {
    this.verifyMediatorScdImportBtn();
  }

  public clickMediatorProjectImportButton() {
    this.clickMediatorScdImportBtn();
  }

  public projectExistedInList(project_name: string) {
    return this.isProjectPresent(project_name);
  }

  public openProject() {
    this.clickProjectButton();
  }

  public clickActionCellButton(project_name: string) {
    this.clickActionCellAsPerProjectName(project_name);
  } 

}