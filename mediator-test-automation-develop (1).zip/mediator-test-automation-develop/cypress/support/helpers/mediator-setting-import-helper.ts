import { MediatorSettingImportPage } from "../pages/mediator-setting-import-page";

export class MediatorSettingImportHelper extends MediatorSettingImportPage {

    public clickOnSettingImportButton() {
        this.clickSettingImportButton();
    }
    
    public verifySettingImportBtn() {
        this.verifySettingImportButton();
    }

    public clickUuidLink() {
        this.selectUuidLink();
    }

    public uploadSettingFile(file: string) {
        this.uploadFile(file);
    }

    public clickOnImportSelection() {
        this.clickImportSelection();
    }

    public clickOnImportSelectionAndWait() {
        this.clickImportSelection();
        this.checkingOverlay();
    }

    public verifyMediatorDataGrid() {
        this.verifyMediatorGrid();
    }

    public clickNextButton() {
        this.clickOnNextButton();
        this.verifyNextBtn();
    }

    public checkNextButton() {        
        this.checkNextBtnEnableState();
    }

    public clickFinishBtn() {
        this.clickOnFinishButton();
    }

    public checkingOverlay() {
        this.verifyOverlay();              
    }

    public getSettingImportDataTop(col_name1: string, col_name2: string) {
        return this.getDataFromMediatorSettingGrid('top',col_name1, col_name2);        
    };

    public getSettingImportDataCenter(col_name1: string, col_name2: string) {
        return this.getDataFromMediatorSettingGrid('center',col_name1, col_name2);        
    };

    public getSettingImportDataBottom(col_name1: string, col_name2: string) {
        return this.getDataFromMediatorSettingGrid('bottom',col_name1, col_name2);  
    };

    public getSettingImportDataFromThreeColTop(col_name1: string,col_name2: string, col_name3: string) {
        return this.getDataFromMediatorSettingGridFromThreeCols('top',col_name1, col_name2, col_name3);        
    };

    public getSettingImportDataFromThreeColCenter(col_name1: string,col_name2: string, col_name3: string) {
        return this.getDataFromMediatorSettingGridFromThreeCols('center',col_name1, col_name2, col_name3);        
    };

    public getSettingImportDataFromThreeColBottom(col_name1: string,col_name2: string, col_name3: string) {
        return this.getDataFromMediatorSettingGridFromThreeCols('bottom',col_name1, col_name2, col_name3);  
    };

    public getSettingImportDataFromFourColTop(col_name1: string,col_name2: string, col_name3: string, col_name4: string) {
        return this.getDataFromMediatorSettingGridFromFourCols('top',col_name1, col_name2, col_name3, col_name4);        
    };

    public getSettingImportDataFromFourColCenter(col_name1: string,col_name2: string, col_name3: string, col_name4: string) {
        return this.getDataFromMediatorSettingGridFromFourCols('center',col_name1, col_name2, col_name3, col_name4);        
    };

    public getSettingImportDataFromFourColBottom(col_name1: string,col_name2: string, col_name3: string, col_name4: string) {
        return this.getDataFromMediatorSettingGridFromFourCols('bottom',col_name1, col_name2, col_name3, col_name4);  
    };

    public verifyErrorMessage() {
        this.verifyErrorMgs();
    }

    public verifyImportSelection() {
        this.verifyImportSelectionButton();
    }

    public exportSettingsInToExcel() {
        this.exportExcel();
    }

    public exportSettingsInToCsv() {
        this.exportCSV();
    }

    public clickCancelButton() {
        this.clcikCancelBtn();
    }
}