export class ScenarioContext {
  /**
   * This method is used to share the data values between step definition and also between test.
   * @param file File path to be passed. All context files are available under  cypress\fixtures\context-sharing
   * @param object The key value that needs to be updated in the JSON
   * @param content The test data to be updated in the Key value to use it across the test
   */
  static updateContextJSON(file: string, object: any, content: string) {
    cy.readFile(file).then((data) => {
      cy.log('Scenario Context-data to be persisted:::' + data.device_name);
      data[object] = content;
      cy.writeFile(file, data);
    });
  }
}
