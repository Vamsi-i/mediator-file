import { FileHandler } from '../file-handler-utils/file-handler';
import { JsonHandler } from '../file-handler-utils/json-handler';
import { Restler } from './restler';

const jira_client = require('jira-connector');
const file_handler: FileHandler = new FileHandler();
export class JiraUtils {
  public static async importTestExecutionResults(json_file: string, xray_test_result_import_uri: string, xray_auth: string) {
    const request_body = await JsonHandler.readJsonFile(json_file);
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(request_body)
    };
    return Restler.postRequestWithHeader(xray_test_result_import_uri, '', options).then(function () {
      console.log('Test Results posted into XRAY');
    });
  }

  public static attachHTMLReport(report: any, test_execution_id: string, xray_auth: string) {
    const jira = new jira_client({
      host: 'stamp.gs.ec.ge.com/jira', //runconfig.jira_host,
      basic_auth: {
        base64: xray_auth
      }
    });
    const opts = {
      filename: report,
      issueKey: test_execution_id,
      headers: {
        'X-Atlassian-Token': 'nocheck'
      }
    };
    return new Promise<any>((resolve) => {
      jira.issue.addAttachment(opts).then(function (issue: any) {
        console.log('Html Report Attached');
        resolve(issue);
      });
    });
  }

  public static exportFeatureFileFromJira(xray_file_path: string, test_execution_id: string, xray_feature_import_uri: string, xray_auth: string) {
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`      
      },
      decoding: 'buffer'
    };
    return Restler.getRequestWithHeader(xray_feature_import_uri + test_execution_id, '', options)
      .then(function (data: any) {
        const res = data.toString();
        if (res.startsWith('@GADM')) { 
          file_handler.writeFile(xray_file_path, data.toString());      
          //file_handler.writeFile(xray_file_path + 'xray-test.feature', data.toString());
        } else {
          //file_handler.writeFile(xray_file_path + 'xray-test.feature', 'Feature: No Test');
          file_handler.handleZipFeatureFile(xray_file_path, data);
        }
      }).catch(err => {
        console.log(err);
      });
  }

  public static createTestExecution(Jira_host: string, test_execution_id: string, xray_auth: string) {
    // const jira: string = JiraUtils.runconfig.jira_host;
    //const testExecution: string = JiraUtils.runconfig.CreateTestExecution;
    const test_execution_request_body = {
      fields: {
        project: {
          key: 'GADM'
        },
        summary: 'Test Execution-Automation',
        description: 'Test Execution created by the Automation Suite',
        issuetype: {
          name: 'Test Execution'
        },
        labels: ['tests']
      }
    };
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(test_execution_request_body)
    };
    return Restler.postRequestWithHeader(Jira_host, test_execution_id, options);
  }

  public static associateTestExecutionWithTestPlan(test_execution_id: string, test_plan_id: string, xray_auth: string, jira_host: string) {
    const test_plan = `/rest/raven/1.0/api/test_plan/${test_plan_id}/testexecution`;
    const test_execution_request_body = {
      add: [test_execution_id]
    };
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(test_execution_request_body)
    };
    return Restler.postRequestWithHeader(jira_host, test_plan, options).then(function () {
      console.log(`Test Execution(${test_execution_id})linked with Test Plan (${test_plan_id})`);
    });
  }

  public static associateTestWithTestExecution(test_execution_id: string, test: string[], jira_host: string, xray_auth: string) {
    // const testExecution: string = runconfig.CreateTestExecution;
    // const test_plan: string = runconfig.Addtest_plan;
    const test_set: string = '/rest/raven/1.0/api/testexec/' + test_execution_id + '/test'; //runconfig.Addtest_set;
    const test_execution_request_body = {
      add: test
    };
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`,
        'Content-Type': 'application/json'
      },
      data: JSON.stringify(test_execution_request_body)
    };
    return Restler.postRequestWithHeader(jira_host, test_set, options).then(function () {
      console.log(`Test Set/Test(${test}) linked with Test Execution(${test_execution_id})`);
    });
  }

  public static async getTestFromTestPlan(test_plan: string, test_status: string, jira_host: string, xray_auth: string, get_test_from_test_planUri: string) {
    const get_test_from_test_plan: string = get_test_from_test_planUri;
    const options = {
      headers: {
        Authorization: `Basic ${xray_auth}`,
        'Content-Type': 'application/json'
      }
    };
    const test: string[] = [];
    await Restler.getRequestWithHeader(jira_host, get_test_from_test_plan.replace('{{test_planKey}}', test_plan), options).then(function (data: any) {
      data.forEach((value: any) => {
        if (value.latest_status === test_status) {
          test.push(value.key);
        } else if (test_status === 'ALL') {
          test.push(value.key);
        }
      });
    });
    return test;
  }
}
