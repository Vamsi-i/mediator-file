export class RestHandler {
  public static getRequest(baseUrl: string, endpointUrl: string, options: any) {
    cy.log(options);
    return cy.request({ method: 'GET', url: baseUrl + endpointUrl }).then(function (response) {
      cy.log('Body:::' + JSON.stringify(response.body));
    });
  }
  /* eslint-disable */
  public static getRequestWithHeader(baseUrl: string, endpointUrl: string, headerOptions: any, failOnStatus:boolean =true) {
    return cy.request({ method: 'GET', url: baseUrl + endpointUrl,failOnStatusCode: failOnStatus,  headers: headerOptions}).then(function (response) {
      // cy.log('requestHeaders:::' + JSON.stringify(response.requestHeaders));
      //cy.log('Body:::' + JSON.stringify(response.body));
    });
  }
  /* eslint-enable */
  public static getRequestOnResponse(baseUrl: string, endpointUrl: string, options: any) {
    cy.log(options);
    return cy.request({ method: 'GET', url: baseUrl + endpointUrl }).then(function (response) {
      cy.log('GET REQUEST Body:::' + JSON.stringify(JSON.stringify(response.body)));
    });
  }

  public static getRedirect(baseUrl: string, endpointUrl: string, options: any) {
    cy.log(options);
    return cy.visit(baseUrl + endpointUrl).then(function (response) {
      cy.log('Response:::' + JSON.stringify(response.Response.toString()));
    });
  }
  /* eslint-disable */
  public static postRequestWithHeader(baseUrl: string, endpointUrl: string, headers: any, requestBody: any, failOnStatus : boolean = true) {
    return cy.request({ method: 'POST', form: true, failOnStatusCode: failOnStatus, url: baseUrl + endpointUrl, headers, body: requestBody }).then(function (response) {
      // cy.log('POST Response headers:::' + JSON.stringify(response.headers));
      // cy.log('POST Response REquest headers:::' + JSON.stringify(response.requestHeaders));
      cy.log('POST Response body:::' + JSON.stringify(response.body));
    });
  }
 
  public static postWithHeader(baseUrl: string, endpointUrl: string, headers: any, requestBody: any, failOnStatus : boolean = true) {
    cy.log('POST REQUEST BODY:::'+JSON.stringify(requestBody));
    return cy.request({ method: 'POST',failOnStatusCode: failOnStatus, url: baseUrl + endpointUrl, headers, body: requestBody });
  }

  public static putRequestWithHeader(baseUrl: string, endpointUrl: string, headers: any, requestBody: any, failOnStatus : boolean = true) {
    cy.log('PUT REQUEST BODY:::'+JSON.stringify(requestBody));
    return cy.request({ method: 'PUT',failOnStatusCode: failOnStatus, url: baseUrl + endpointUrl, headers, body: requestBody });
  }
  public static deleteRequestWithHeader(baseUrl: string, endpointUrl: string, headers:any ,failOnStatus:boolean = true) {
    return cy.request({ method: 'DELETE',failOnStatusCode: failOnStatus, url: baseUrl + endpointUrl,headers }).then(function (response) {
      cy.log('Delete Request Status:'+response.status);
    });
  }
}

 /* eslint-enable */
