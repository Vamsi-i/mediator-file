/* eslint-disable */
import { IncomingMessage, ServerResponse } from 'http';
import * as rest from 'restler';

export class Restler {
  public static async getRequestWithHeader(baseUrl: string, endpointUrl: string, options: any) {
    return new Promise<any>(resolve => {
      rest.get(baseUrl + endpointUrl, options).on('complete', function (data: any) {
        resolve(data);
      });
    });
  }


  public static async getRequestOnResponse(baseUrl: string, endpointUrl: string, options: any) {
    return new Promise<any>(resolve => {
      rest.get(baseUrl + endpointUrl, options).on('response', function (data: any) {
        resolve(data.rawHeaders);
      });
    });
  }

  
  public static async postRequestWithHeader(baseUrl: string, endpointUrl: string, options: any): Promise<any> {
    let resp: any;
    return new Promise<any>(function (resolve, reject) {
      rest.post(baseUrl + endpointUrl, options).on('complete', function (data: any, response: any) {
        console.log(response);
        resp = data;
        if (data) {
          JSON.stringify(data);
          resolve(resp);
        }
        else
          reject();
      });
    });
  }
  public static async postRequestOnResponse(baseUrl: string, endpointUrl: string, options: any) {
    let resp: any;
    return new Promise<any>(resolve => {
      rest.post(baseUrl + endpointUrl, options).on('response', function (data: any) {
        resp = data;
        // console.log("Restler POST::", resp);
        resolve(resp);
      });
    });
  }
  public static async putRequest(baseUrl: string, endpointUrl: string, requestBody: any) {
    let resp: any;
    rest.putJson(baseUrl + endpointUrl, requestBody).on('complete', function (result: any, response: any) {
      resp = response;
    });
    return resp;
  }

  public static async put_Request(baseUrl: string, endpointUrl: string, requestBody: any) {
    let resp: any;
    return new Promise<any>(resolve => {
      rest.putJson(baseUrl + endpointUrl, requestBody).on('complete', function (data: any) {
        resp = data;
        //console.log("Restler PUT::", resp);
        resolve(resp);
      });
    });
  }
  public static async deleteRequest(baseUrl: string, endpointUrl: string) {
    let resp: any;
    rest.del(baseUrl + endpointUrl).on('complete', async (result: any, response: any) => {
      resp = response;
    });
    return resp;
  }
  public static async delete_Request(baseUrl: string, endpointUrl: string) {
    let resp: any;
    return new Promise<any>(resolve => {
      rest.del(baseUrl + endpointUrl).on('complete', function (data: any) {
        resp = data;
        //console.log("Restler DEL::", resp);
        resolve(resp);
      });
    });
  }
  public static async deleteRequestWithHeader(baseUrl: string, endpointUrl: string, options: any) {
    let resp: any;
    return new Promise<any>(resolve => {
      rest.del(baseUrl + endpointUrl, options).on('complete', function (data: any) {
        resp = data;
        //console.log("Restler DEL::", resp);
        resolve(resp);
      });
    });
  }
}
