/* eslint-disable */
import { JiraUtils } from '../common-utils/jira';
import { FilePath } from './file-path';
import { YamlReader } from '../file-handler-utils/yaml-reader';
import { FileHandler } from '../file-handler-utils/file-handler';

export class EnvironmentConfig {
  private static url: string;
  public static postgress: string;
  public static xray: string;
  public static environment: string;
  public static testExecutionId: string;
  private static credential: string;
  public static test_context: any;

  static getUrl() {
    return EnvironmentConfig.url;
  }

  static getCredential() {
    return EnvironmentConfig.credential;
  }


  static getRunConfig() {
    const runconfig: any = YamlReader.readYML(FilePath.runConfigLocation).then((doc: any) => {
      EnvironmentConfig.environment = doc.Environment;
      EnvironmentConfig.xray = doc.Xray;
      EnvironmentConfig.testExecutionId = doc.TestExecutionId;
      cy.log('environment:::' + EnvironmentConfig.environment);
    });
    cy.log('environment:::' + this.environment);
    return runconfig;
  }

  static getEnvironmentConfig() {
    const content: any = YamlReader.readYML(FilePath.environmentFilePath).then((doc: any) => {
      EnvironmentConfig.url = doc[EnvironmentConfig.environment].url;
      EnvironmentConfig.postgress = doc[EnvironmentConfig.environment].postgress;
      cy.log('URL:::' + EnvironmentConfig.url);
      cy.log('postgress:::' + EnvironmentConfig.postgress);
    });
    cy.log('URL:::' + EnvironmentConfig.url);
    cy.log('postgress:::' + EnvironmentConfig.postgress);
    return content;
  }

  static setEnvironmentCredentials(userType: string) {
    const doc: any = YamlReader.readYML(FilePath.environmentFilePath).then(function (doc: any) {
      EnvironmentConfig.credential = userType == 'Admin'
        ? doc[EnvironmentConfig.environment].admin
        : userType == 'Customer'
          ? doc[EnvironmentConfig.environment].customer
          : userType == 'Viewer'
            ? doc[EnvironmentConfig.environment].viewer
            : 'UserType is not defined';
      cy.log('Credentials:::' + EnvironmentConfig.credential);
    });
    return doc;
  }

  static async setUpXray() {
    let testExecutionId ;
    const runconfig: any = YamlReader.readYAML(FilePath.runConfigLocation);
    const jiraHost: string = runconfig.JiraHost;
    const testExecution: string = runconfig.CreateTestExecution;
    const xrayAuth: string = runconfig.XrayAuth;
    const releaseTestPlan: string = runconfig.ReleaseTestPlan;
    const getTestFromTestPlanUri: string = runconfig.GetTestFromTestPlan;
    const XrayFeatureImportUri: string = runconfig.XrayFeatureImport;
    const xrayTestResultImportUri: string = runconfig.XrayTestResult;
    const testPlanNumber = runconfig.Test.includes('Smoke Test')
      ? runconfig.SmokeTestPlan
      : runconfig.Test.includes('Xray')
        ? runconfig.ReleaseTestPlan
        : 'Not Applicable';

    if (
      runconfig.Xray === 'Y' &&
      (runconfig.Test === 'Xray- Execute Tests with ANY status from Test Plan' ||
        runconfig.Test === 'Xray- Execute Tests with PASS status from Test Plan' ||
        runconfig.Test === 'Xray- Execute Tests with TODO status from Test Plan' ||
        runconfig.Test === 'Xray- Execute Tests with FAIL status from Test Plan' ||
        runconfig.Test === 'Smoke Test')
    ) {
      const testStatusToRun = runconfig.Test.includes('PASS')
        ? 'PASS'
        : runconfig.Test.includes('FAIL')
          ? 'FAIL'
          : runconfig.Test.includes('TODO')
            ? 'TODO'
            : 'ALL';

      await JiraUtils.createTestExecution(jiraHost, testExecution, xrayAuth).then(async function (data: any) {
        testExecutionId = data.key;
        console.log('Test Execution Created with ID:', testExecutionId);
        await JiraUtils.associateTestExecutionWithTestPlan(testExecutionId, testPlanNumber, xrayAuth, jiraHost);
        await JiraUtils.getTestFromTestPlan(
          testPlanNumber,
          testStatusToRun,
          jiraHost,
          xrayAuth,
          getTestFromTestPlanUri
        ).then(async function (value: any) {
          console.log(`Tests retrieved from Test Plan(${testPlanNumber}) :${value}`);
          await JiraUtils.associateTestWithTestExecution(testExecutionId, value, jiraHost, xrayAuth).then(
            async function (data) {
              await JiraUtils.exportFeatureFileFromJira(FilePath.xrayFilePath, testExecutionId, XrayFeatureImportUri, xrayAuth);
            }
          );
        });
      });
    }
    if (runconfig.Xray === 'Y' && runconfig.Test === 'Xray- Enter Test Execution Id') {
      await JiraUtils.exportFeatureFileFromJira(FilePath.xrayFilePath, runconfig.TestExecutionId, XrayFeatureImportUri, xrayAuth);
    }
    return testExecutionId;

  }

  static async tearDown(testExecutionId: string) {
    {
      const runconfig: any = YamlReader.readYAML(FilePath.runConfigLocation);
      const jiraHost: string = runconfig.JiraHost;
      if (
        runconfig.Xray === 'Y') {
        const testExecutionIdXray: string =
          typeof testExecutionId == 'undefined' ? runconfig.TestExecutionId : testExecutionId;
        const xrayAuth: string = runconfig.XrayAuth;
        const xrayTestResultImportUri: string = runconfig.XrayTestResult;
        await JiraUtils.importTestExecutionResults(FilePath.cucumberJSONReportFile, xrayTestResultImportUri, xrayAuth);
        await FileHandler.zipFolder(FilePath.htmlReport, 'report');
        return JiraUtils.attachHTMLReport(FilePath.htmlReportFile, testExecutionIdXray, xrayAuth);
      }    
    }
  }
}
