import { FilePath } from './file-path';
import { YamlReader } from '../file-handler-utils/yaml-reader';

export class Config {
  static getLoginDetails(user_type: string) {
    const login = YamlReader.readYML(FilePath.runConfigLocation).then(function (run_details: any) {
      cy.log(`Running test in ${run_details.Environment} Environment....`);
      YamlReader.readYML(FilePath.environmentFilePath).then(function (doc: any) {
        const environment: any = {};
        const credential =
          user_type == 'Admin'
            ? doc[run_details.Environment].admin
            : user_type == 'Customer'
              ? doc[run_details.Environment].customer
              : user_type == 'Viewer'
                ? doc[run_details.Environment].viewer
                : 'user_type is not defined';
        environment.username = credential.split(',')[0];
        environment.password = credential.split(',')[1];
        environment.url = doc[run_details.Environment].url;
        return environment;
      });
    });
    return login;
  }

  static getDatabaseConnection() {
    const db = YamlReader.readYML(FilePath.runConfigLocation).then(function (run_details: any) {
      YamlReader.readYML(FilePath.environmentFilePath).then(function (doc: any) {
        const postgress:string = doc[run_details.Environment].postgress;
        const connection:any =  {
          'user': postgress.split(';')[1],
          'password': postgress.split(';')[2],
          'host': postgress.split(';')[0],
          'database': postgress.split(';')[3],
          'port':postgress.split(';')[4]
        };
        return connection;
      });
    });
    return db;
  }
}
