export class FilePath {
  public static environmentFilePath = 'cypress/fixtures/config-data/environment.yml';
  public static runConfigLocation = 'cypress/fixtures/config-data/run-config.yml';
  public static xrayFilePath = 'cypress/integration/features/xray/xray-test.feature';
  //public static xrayFilePath = 'cypress/integration/features/xray/';
  public static apiFilePath = 'cypress/fixtures/config-data/endpoint-urls.yml';
  public static navigate = 'cypress/fixtures/config-data/navigate.yml';

  //Xray Payload
  public static createTestExecution = 'payload/xray/CreateTestExecution.json';
  public static linkTestExecToTestPlan = 'payload/xray/LinkTestExecToTestPlan.json';

  //Report
  public static htmlReport = 'cypress/report/html-report/';
  public static cucumberJSONReport = 'cypress/report/cucumber-json/';
  public static htmlReportFile = 'cypress/report/html-report/report.zip';
  public static cucumberJSONReportFile = 'cypress/report/cucumber-json/xray-test.cucumber.json';
  public static report = 'cypress/report';
  
  //Payload File Path - API Test Data
  public static executeOperation = 'payload/operation.json';
  public static createEdge = 'payload/edge/Create_edge.json';
  public static createScheduler = 'payload/scheduler.json';
  public static createInstance = 'payload/instance/Create_instance.json';
  public static consentBody = 'payload/auth/consent.json';
  public static tokenBody = 'payload/auth/token.json';
  public static adminUser = 'payload/auth/adminUser.json';
  public static viewerUser = 'payload/auth/viewerUser.json';
  public static createWorkspace = 'payload/workspace/Create_workspace.json';
  public static updateInstance = 'payload/instance/Update_instance.json';
  public static addScheduler = 'payload/scheduler/create_scheduler.json';

  //Context sharing
  public static logs_context = 'cypress/fixtures/context-sharing/logs.json';
  public static bcu_files = 'cypress/fixtures/context-sharing/bcu-generator.json';

  //BCU data model path
  public static path_storage = 'docker/misc/storage/devices/';
  public static path_cid = '/configuration/unzip/Test_BCU/Test_BCU/Test_BCU.cid';
  public static path_mappingrules = 'testdata/data-model/mappingRules.json';
  public static path_xmlfile = '/configuration/unzip/Test_BCU/Test_BCU/Test_BCU.xml';
  public static path_inrefmapping_file = 'testdata/InRefExtref/inrefmappingfile.json';

  //Docker file
  public static docker = 'docker/.env';
  public static records_context = 'cypress/fixtures/context-sharing/records.json';

  //IEC Device 
  public static iec_file = 'testdata/iec61850/';

  // mediator setting import
  public static scd_file = 'testdata/mediator-scd-import/';
  public static setting_file = 'testdata/mediator-setting-import/';
  public static setting_import_data = 'cypress/fixtures/context-sharing/mediator_setting_import.json';
  public static csv_file = 'export.csv';
  public static excel_file = 'export.xlsx';

  // BCU generator
  public static bap_table = 'testdata/import-private-section/bap/baptable.json';

}