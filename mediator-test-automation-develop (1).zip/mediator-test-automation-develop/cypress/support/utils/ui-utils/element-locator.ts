export class DOMElement {
  /**
   * This method is used to invoke the get() method provided by the cypress to find the element
   * @param locator The parameter to be passed to get() which is the parent locator
   */
  protected getElement(locator: string, elementType?: string) {
    if (elementType === 'xpath') {
      return cy.xpath(locator);
    }
    else if (elementType === 'contains') {
      return cy.contains(locator);
    }
    return cy.get(locator);
  }

  /**
   * This method is used to invoke the find() search provided by the Cypress
   * @param locator The parameter to be passed to get() which is the parent locator
   * @param findElement The element which is to be searched under the parent element
   */
  protected findElement(locator: string, findElement: string,elementType?:string) {
    if (elementType === 'xpath') { // need testing
      return cy.xpath(locator).find(findElement);
    }
    else if (elementType === 'contains') {
      return cy.contains(locator).find(findElement);
    }
    return cy.get(locator).find(findElement);

  }

  /**
   * This method is used to wait until as per condition
   * @param locator The parameter to be passed to get() which is the parent locator
   * @param wait_time is the wait time
   * @param condition condition [be.visible, not.exist]
   */
  protected waitUntil(locator: string, wait_time: any, condition: string, elementType?: string) {
    if (condition === 'visible') {
      if (elementType === 'xpath') {
        cy.xpath((locator), { timeout: wait_time }).should('be.visible');
      }
      else if (elementType === 'contains') {
        cy.contains((locator), { timeout: wait_time }).should('be.visible');
      }
      cy.get((locator), { timeout: wait_time }).should('be.visible');
    }

    else if (condition === 'not_exist') {
      if (elementType === 'xpath') {
        cy.xpath((locator), { timeout: wait_time }).should('not.exist');
      }
      else if (elementType === 'contains') {
        cy.contains((locator), { timeout: wait_time }).should('not.exist');
      }
      cy.get((locator), { timeout: wait_time }).should('not.exist');
    }  

  }

  /**
   * This method is used to wait until as per condition
   * @param locator The parameter to be passed to get() which is the parent locator
   * @param wait_time is the wait time
   * @param condition condition [be.visible, not.exist]
   * @param condition_value value for condition
   */
  protected waitUntilTextMatch(locator: string, wait_time: any, condition: string, condition_value: string, elementType?: string) {
    if (condition === 'contain') {
      if (elementType === 'xpath') {
        cy.xpath((locator), { timeout: wait_time }).should('contain',condition_value);
      }
      else if (elementType === 'contains') {
        cy.contains((locator), { timeout: wait_time }).should('contain',condition_value);
      }
      cy.get((locator), { timeout: wait_time }).should('contain',condition_value);
    }

  }

}
