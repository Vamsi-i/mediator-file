//import { reject } from 'cypress/types/lodash';
//import { resolve } from 'path';
import { DOMElement } from './element-locator';

export class UIHandler extends DOMElement {
  protected launchWebSite(url: string) {
    cy.log('Launching Url::' + url);
    cy.visit(url);
  }

  public static deleteAllCookies() {
    cy.clearCookies();
    cy.getCookies().should('be.empty');
  }

  protected enterText(element_locator: string, value: string, element_type?: string) {
    return this.getElement(element_locator, element_type).type(value);
  }

  protected scrollIntoView(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).scrollIntoView();
  }

  protected scrollToTopByJS() {
    cy.scrollTo('top');
  }

  protected scrollToBottomByJS() {
    cy.scrollTo('bottom');
  }

  protected scrollToTopLeft() {
    cy.scrollTo('topLeft');
  }

  protected scrollToTopRight() {
    cy.scrollTo('topRight');
  }

  protected scrollToBottomRight() {
    cy.scrollTo('bottomRight');
  }

  protected scrollToBottomLeft() {
    cy.scrollTo('bottomLeft');
  }

  protected scrollToCenter() {
    cy.scrollTo('center');
  }

  protected scrollToLeft() {
    cy.scrollTo('left');
  }

  protected scrollToRight() {
    cy.scrollTo('right');
  }

  protected scrollToOffsetByJS(x: number, y: number) {
    cy.scrollTo(x, y);
  }

  protected scrollToOffsetByOption(x: number, y: number, option: any) {
    cy.scrollTo(x, y, option);
  }

  protected verifyAttributeText(element_locator: string, attribute: string, text: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('have.attr', attribute).and('include', text);
  }
  protected rightClickElement(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).rightclick();
  }

  protected verifyAttributeShouldNotHaveText(element_locator: string, attribute: string, text: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('have.attr', attribute).and('not.be.a', text);
  }

  protected attachFile(element_locator: string, file: string, element_type?: string) {
    this.getElement(element_locator, element_type).attachFile(file);
  }
  
  protected clickElement(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).click();
  }

  protected clickDragAndDropElement(element_locator: string, coordinates: any, element_type?: string) {
    this.getElement(element_locator, element_type).trigger('click').trigger('dragstart').trigger('drop', coordinates);
  }

  protected getAttributeValue(element_locator: string, attribute_name: string, attribute_value: string, element_type?: string) {
    return this.getElement(element_locator, element_type).invoke(attribute_name, attribute_value);
  }

  protected getTitle() {
    cy.title();
  }

  protected getChildElement(element_locator: string, child: string, element_type?: string) {
    return this.getElement(element_locator, element_type).children(child);
  }

  protected waitForElement(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('be.visible');
  }

  protected isElementPresent(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('be.visible', () => {
      return false;
    });
    return true;
  }
  protected isElementInDom(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('exist', () => {
      return false;
    });
    return true;
  }
  protected isElementNotInDom(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('not.exist', () => {
      return false;
    });
    return true;
  }
  protected doesUrlContains(url_text: string) {
    cy.url().should('include', url_text);
  }

  isElementNotPresent(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('not.be.visible', () => {
      return false;
    });
    return true;
  }

  static wait(TIMEINMS: number) {
    cy.wait(TIMEINMS);
  }

  protected refreshPage() {
    cy.reload();
  }

  protected navigateBack() {
    cy.go('back');
  }

  protected navigateForward() {
    cy.go('forward');
  }

  // check if this is required. looks similar to locator is present
  isDisplayed(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('be.visible');
  }

  protected isEnabled(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('be.enabled');
  }

  protected isDisabled(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('not.be.enabled');
  }
  protected isSelected(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).should('be.checked');
  }
  protected pressTabKey(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).type('{tab}');
  }

  protected pressDownKey(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).type('{downArrow}');
  }

  protected pressEnterKey(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).type('{enter}');
  }

  protected getTextArray(element_locator: string, type: string, element_type?: string): Promise<any> {
    return new Promise<any>(function (resolve, reject) {
      this.findElement(element_locator, type, element_type).then((value) => {
        if (value) {
          cy.log('Text received::' + value.text().toString());
          resolve(value.text().toString());
        } else reject();
      });
    });
  }
  selectValueFromDropDown(element_locator: string, value: string, element_type?: string) {
    this.getElement(element_locator, element_type).select(value);
    this.getElement(element_locator, element_type).should('have.value', value);
  }
  validateTitle(title: string) {
    cy.title().should('eq', title);
  }

  verifyTextPresent(element_locator: string, text: string, element_type?: string) {
    this.getElement(element_locator, element_type).then((extracttext: any) => {
      expect(text).equals(extracttext.text().toString());
    });
  }

  protected switchToFrameBylocator(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type);
  }

  protected getCountByFindElement(element_locator: string, findelement_locator: string,element_type?: string) {
    return this.findElement(element_locator, findelement_locator,element_type);
  }

  protected checkIfEleExistsThenClick(parentEle: string,ele: string): Promise<any>{
    return new Promise<any>(function(){

      Cypress.on('fail', () => {
        return false;
      });
        
      cy.get( parentEle ).find(ele).its('length').then(res=>{
        if(res > 0){                
          cy.get(ele).click();
        }
        else{
          assert.isOk('OK', 'Element does not exist.');
        }
      });   
        
    });
  }

  protected getText(element_locator: string, element_type?: string){
    return this.getElement(element_locator, element_type).then(value => {
      return value.text().toString();
    });

  }

  waitForAsyncCalls(function_to_call: any, message: string, parameters: any, increment = 0, abort = false) {
    cy.log('Current increment::'+increment+ ' Waits till increment to be 500...');
    if (increment <= 500) {
      //const function_response = function_to_call(parameters);
      function_to_call(parameters).then((result: any) => {
        if (result.length > 0 || result == true) {
          abort == true;
        } else {
          cy.log(message);
          cy.wait(2000);
          this.waitForAsyncCalls(function_to_call, message, parameters, increment + 1, abort);
        }
      });
    }
    else{
      abort = true;
    }
  }

  protected checkIfElementExists(element_locator: string) {
    return cy.get('body').then(($body) => {
      if ($body.find(element_locator).length) {
        return true;
      } else {
        // Throws no error when element not found
        assert.isOk('OK', 'Element does not exist.');
        return false;
      }
    });

  }  

  protected clickHiddenElement(element_locator: string, element_type?: string) {
    this.getElement(element_locator, element_type).click({force: true});
  }
}