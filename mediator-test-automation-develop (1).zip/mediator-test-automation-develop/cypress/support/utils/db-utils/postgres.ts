import { Client } from 'pg';

export class Postgress {
  public async connectPostgresDatabase(
    hostValue: string,
    portValue: number,
    databaseValue: string,
    userName: string,
    passwordValue: string,
  ) {
    const client = new Client({
      user: userName,
      host: hostValue,
      database: databaseValue,
      password: passwordValue,
      port: portValue,
    });

    await client.connect();
    return client;
  }

  public executeQuery(query: string, client: any) {
    return new Promise((resolve, reject) => {
      try {
        const result = client.query(query);
        resolve(result);
      } catch (e) {
        reject(e);
      }
    });
  }

  public async closePostgres(client: any) {
    return await client.end();
  }

  public async deleteAllRowsFromTable(tableName: string, client: any) {
    const res = await client.query(`DELETE FROM ${tableName}`);
    return res;
  }
}
