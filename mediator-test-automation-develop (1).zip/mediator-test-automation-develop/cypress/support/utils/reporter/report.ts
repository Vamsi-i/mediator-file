import { FilePath } from '../config-utils/file-path';

const report = require('multiple-cucumber-html-reporter');

export class Reporter {
  public static publishReport() {
    report.generate({
      jsonDir: FilePath.cucumberJSONReport,
      reportPath: FilePath.htmlReport,
      customData: {
        title: 'GDM Functional Test Automation',
        data: [
          { label: 'Project', value: 'GDM' },
          { label: 'Release', value: '0.10.8' },
          { label: 'Execution Start Time', value: new Date() },
          { label: 'Execution End Time', value: new Date() }
        ]
      }
    });
  }
}
