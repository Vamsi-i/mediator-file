import * as fs from 'fs';
export class JsonHandler {

  //This code may not work in cypress. needs fix
  static readJsonFile(file: string) {
    const json_text = JSON.parse(fs.readFileSync(file).toString());
    return json_text;
  }

  static readJson(file: string) {
    return cy.fixture(file);
  }
}
