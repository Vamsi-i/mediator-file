import YAML from 'yamljs';
import * as fs from 'fs';
import * as yaml from 'js-yaml';
const encoding = 'utf8';
export class YamlReader {

  // public static readYML(filePath: string) {
  //   const doc: any =  cy.readFile(filePath).then(function (content){
  //       return YAML.parse(content);
  //   });    
  //   return doc;
  // }

  static readYAML(filePath: string) {
    let doc: any = '';
    yaml.safeLoadAll(fs.readFileSync(filePath, encoding), function (data: any) {
      doc = data;
    });
    return doc;
  }

  static readYML(filePath: string) {
    const doc: any =  cy.readFile(filePath).then(function (content){
      return YAML.parse(content);
    });    
    return doc;
  }

}