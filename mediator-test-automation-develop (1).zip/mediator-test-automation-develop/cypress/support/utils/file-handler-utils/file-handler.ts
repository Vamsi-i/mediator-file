import { readdirSync, readFileSync, writeFile, appendFileSync, unlink, truncate } from 'fs';
import { join } from 'path';
import AdmZip from 'adm-zip';

export class FileHandler {
  //This may not work in Cypress
  public writeFile(file: string, data: any) {
    writeFile(file, data, (err: any) => {
      if (err) console.log(err);
    });
  }

  public writeAppendFile(file: string, data: any) {
    appendFileSync(file, data);
  }

  public handleZipFeatureFile(file: string, data: any) {
    truncate(file, 0, () => {
      // do nothing.
    });
    writeFile('FeatureBundle.zip', data, err => {
      if (err) {
        console.log(err.message);
      } else {
        const zip = new AdmZip('FeatureBundle.zip');
        const entries = zip.getEntries();
        let counter = 0;
        writeFile(file, '', () => {
          // do nothing.
        }); 
        entries.forEach(e => { 
          if (counter == 0) {
            appendFileSync(file, e.getData().toString('utf8') + '\n\n' + '\t');
          }
          else {            
            const index = e.getData().toString('utf8').indexOf(':');
            const sub_string = e.getData().toString('utf8').slice(index, e.getData().toString('utf8').length);
            const index2 = sub_string.indexOf('@GADM');           
            appendFileSync(file, sub_string.slice(index2, sub_string.length) + '\n\n' + '\t');
          }  
          counter = counter + 1; 
          //writeFile(file + e.name, e.getData().toString('utf8'), () => {});          
        });
        unlink('FeatureBundle.zip', () => {
          // do nothing.
        });
      }
    });
  }

  public writeToFile(file: string, data: any) {
    cy.writeFile(file, data);
  }


  readAllFilesFromDirectory(dirPath: string) {
    const dsls: string[] = [];
    const files = readdirSync(dirPath);
    for (const file of files) {
      const content = readFileSync(join(dirPath, `/${file}`), 'utf8');
      dsls.push(content);
    }
    return dsls;
  }

  readFile(filePath: string) {
    const dsl: string = readFileSync(filePath, 'utf8');
    return dsl;
  }

  static zipFolder(folderPath: string, folderName: string) {
    const zip = new AdmZip();
    zip.addLocalFolder(folderPath,folderName+'.zip');
    return zip.writeZip(folderPath+folderName+'.zip');
  }
}
