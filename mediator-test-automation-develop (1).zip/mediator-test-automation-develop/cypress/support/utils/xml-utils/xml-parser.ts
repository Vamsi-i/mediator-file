// import * as xmlParser from 'fast-xml-parser';
// import { appendFileSync } from 'fs';
// //const {XMLParser} = require('fast-xml-parser');
// let tags='';
// const path: string[]=[];

// export class XmlAndJSONParser {
//   public j2xParser = xmlParser.j2xParser;
//   options = {
//     attributeNamePrefix: '',
//     attrNodeName: 'attribute', //default is false
//     textNodeName: '#text',
//     ignoreAttributes: false,
//     cdataTagName: '__cdata', //default is false
//     cdataPositionChar: '\\c',
//     format: true,
//     indentBy: '    ',
//     supressEmptyNode: false,
//     encodeURI
//   };

//   generateXml(jsonObj: any) {
//     const parser = new this.j2xParser(this.options);
//     return parser.parse(jsonObj);
//   }

//   async parseXml(data: string) {
//     return xmlParser.parse(data, this.options);
//   }
//   async parsejson(jsonParsedArray:any,key:string){
//     const self = this;
//     console.log(key);
//     if (jsonParsedArray[key] instanceof Object || jsonParsedArray[key] instanceof Array)
//     { 
//       tags = tags+':'+key;
//       Object.keys(jsonParsedArray[key]).forEach(async function(key1){
//         if(key1!='attribute'){
//           tags = tags+':'+key1;
//           await self.parsejson(jsonParsedArray[key],key1);
//           //console.log(key1,jsonParsedArray[key][key1]);
//         }  
//         // if(key1=='attribute'){
//         //   console.log("SceId::"+jsonParsedArray[key][key1]['SceId']);
//         //   console.log("SceIndex::"+jsonParsedArray[key][key1]['SceIndex']);
//         //   console.log("SceNorgint::"+jsonParsedArray[key][key1]['SceNorgint']);
//         // }  
//       });
     
//     }
//     else
//     {
//       appendFileSync('./testdata/results.txt',key+': '+jsonParsedArray[key]+'\r\n');
//       //tags = tags+':'+key;
//       path.push(tags);
//       //console.log(path);
//     }
//   }
// }
