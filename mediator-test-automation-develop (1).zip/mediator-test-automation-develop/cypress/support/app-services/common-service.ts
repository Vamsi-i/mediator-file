import { RestHandler } from "../utils/common-utils/rest";

export class CommonService {
  
  public getUnits(baseUrl:string,addDataSetUri:string, requestHeader:any, failOnStatus: boolean) {
    return RestHandler.getRequestWithHeader(baseUrl, addDataSetUri, requestHeader,failOnStatus);
  }

  public getUnitCompile(baseUrl:string,addDataSetUri:string, requestHeader:any, failOnStatus: boolean) {
    return RestHandler.getRequestWithHeader(baseUrl, addDataSetUri, requestHeader,failOnStatus);
  }
  
}
