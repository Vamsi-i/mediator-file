// ***********************************************************
// This example support/index.js is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands';
import "cypress-cucumber-attach-screenshots-to-failed-steps";
require('cypress-xpath');
// Alternatively you can use CommonJS syntax:
// require('./commands')

// Cypress.on('test:after:run', (test, runnable) => {
    // if (test.state === 'failed') {
    //     const title = (test.title).replace('#', '%23'); // Todo: need code refining
    //     const screenshot = `${Cypress.config('screenshotsFolder')}/${Cypress.spec.name}/${runnable.parent.title} -- ${title} (failed).png`; //${Cypress.config('screenshotsFolder')}`;
    //     addContext({ test }, screenshot)        
    // }
    // addContext({ test }, 'testExecutionId:::'+testExecutionId);      
// })

Cypress.on('test:after:run', (test, runnable) => {  
  // console.log('Test Status::'+test.state);
  // console.log('Entered After run to Log off GDM Application');  
  
})