import { CommonService } from "../app-services/common-service";

export class CommonServiceHelper extends CommonService {  

  getAllUnits(baseUrl: string, addDataSetUri: string,requestHeader: any, failOnStatus: boolean) { 
    return this.getUnits(baseUrl, addDataSetUri, requestHeader,failOnStatus);
  }

  getJsonPayload(baseUrl: string, addDataSetUri: string,requestHeader: any, failOnStatus: boolean) { 
    return this.getUnitCompile(baseUrl, addDataSetUri, requestHeader,failOnStatus);
  }
 
}