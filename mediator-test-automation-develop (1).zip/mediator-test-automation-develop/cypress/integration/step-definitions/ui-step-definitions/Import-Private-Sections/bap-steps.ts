import { When, Then } from "cypress-cucumber-preprocessor/steps"
import { CommonServiceHelper } from "../../../../support/app-helpers/common-service-helper";
import { DeviceProfilePageHelper } from "../../../../support/helpers/device-profile-page-helper";
import { TopologyPageHelper } from "../../../../support/helpers/topology-page-helper";
import { FilePath } from "../../../../support/utils/config-utils/file-path";
import { YamlReader } from "../../../../support/utils/file-handler-utils/yaml-reader";
import { parseString } from 'xml2js';

let Uuid: string;
let Bap_scd_file: any = [];

When('Open device {string} and Get device uuid', function (device_name: string) {
    let topology_page_obj: TopologyPageHelper = new TopologyPageHelper();
    const device_profile_obj: DeviceProfilePageHelper = new DeviceProfilePageHelper();
    topology_page_obj.goToDeviceView();
    device_profile_obj.getAssetID().then((asset_id:any)=>{
        Uuid = asset_id;        
    });

});

When('Get configuration data using API and verify bap table data with expected bap table data from storage-model', function() {
    YamlReader.readYML(FilePath.apiFilePath).then(function(doc: any) {
        //Uuid = 'dded8885-b725-4a50-9ef0-ef476a503d66'
        const base_url = doc.ConfigurationUri;
        const get_units_url = doc.GetAllUnitsByVersion.replace('{{uuid}}', Uuid);
        const common_service_Obj: CommonServiceHelper = new CommonServiceHelper();
        const headers = {
            'Content-Type': 'application/json'
        };
        common_service_Obj.getAllUnits(base_url, get_units_url, headers, false).then(response => {
            let flag: string = 'False'
            for (let i = 0; i < response.body.length; i++) {
                if (response.body[i].data.bapVariants) {
                    flag = 'True'
                    const bap_veriants = (response.body[i].data.bapVariants)
                    //cy.log(response.body[i].data.bapVariants)
                    cy.readFile('cypress/fixtures/' + FilePath.bap_table).then(json_data => {
                        for (let item in json_data) {
                            //cy.log(item, json_data[item]);
                            let bap_table_item = bap_veriants[item]
                            for (let [key, value] of Object.entries(json_data[item])) {
                                if (key in bap_table_item) {
                                    assert.deepEqual(value, bap_table_item[key], 'bap table value ' + key + ' in ' + item)
                                    //cy.log(value);
                                    //cy.log(bap_table_item[key])
                                }
                                
                            }

                        }
                        
                    });

                }                
            }
            if(flag == 'False') {
                assert.fail('Bap veriant table not found');
            }
        });
    });
});

When('Get the BAP Variant details {string} from scd file {string}', function (data_point: string, file_name: string) {
    cy.readFile('cypress/fixtures/' + FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
        parseString(xmldata, function (err: any, results: any) {
            Bap_scd_file = []
            const ld_count = Object.keys(results.SCL.IED[1].AccessPoint[0].Server[0].LDevice).length;
            //cy.log(ld_count)
            for (let i = 0; i < ld_count; i++) {
                const ldeviceinst: any = results.SCL.IED[1].AccessPoint[0].Server[0].LDevice[i].$['inst'];
                if (ldeviceinst == data_point) {
                    let BAP: any = results.SCL.IED[1].AccessPoint[0].Server[0].LDevice[i].LN0[0].DOI
                    BAP.forEach((element: any) => {
                        //cy.log(element)
                        if ('Private' in element) {
                            if (element['Private'][0].$['type'] == 'RTE-BAP') {                                
                                Bap_scd_file.push({
                                    "name": element.$['name'],
                                    "variant": element['Private'][0]['rte:BAP'][0].$['variant'],
                                    "defaultValue": element['Private'][0]['rte:BAP'][0].$['defaultValue']
                                });
                            }
                        }
                    });
                    cy.log(Bap_scd_file)
                }
            }
        });
    });
});

Then('Get BAP Variant details from configuration using API and compare BAP Variant details {string} from scd and configuration', function(data_point: string) {
    YamlReader.readYML(FilePath.apiFilePath).then(function(doc: any) {
        Uuid = 'b716a8ce-4387-440f-a4a8-c7d79e1a677c'
        const base_url = doc.ConfigurationUri;
        const get_units_url = doc.GetAllUnitsByVersion.replace('{{uuid}}', Uuid);
        const common_service_Obj: CommonServiceHelper = new CommonServiceHelper();
        const headers = {
            'Content-Type': 'application/json'
        };
        common_service_Obj.getAllUnits(base_url, get_units_url, headers, false).then(response => {
                
            for (let i = 0; i < response.body.length; i++) {
                //cy.log(response.body[i].data)
                for (const res in response.body[i].data) {
                    if (data_point == 'LDPX') {
                        data_point = 'distance'
                    }
                    if (res.includes(data_point) || res.includes(data_point.replace('LD', ''))) {
                        //cy.log(response.body[i].data[res])
                        for (const datapoint in response.body[i].data[res]) {
                            //cy.log(response.body[i].data[res][datapoint])
                            for (const ele in response.body[i].data[res][datapoint]) {
                                //cy.log(response.body[i].data[res][datapoint][ele])
                                //below if condition will consider for only LDPX datapoint
                                if (response.body[i].data[res][datapoint][ele] == 'Schemes') {
                                    for (const scheme in response.body[i].data[res][datapoint]) {
                                        //cy.log(response.body[i].data[res][datapoint][scheme])
                                        for (const scheme_ele in response.body[i].data[res][datapoint][scheme]) {
                                            compareBapVeriants(response.body[i].data[res][datapoint][scheme][scheme_ele])
                                        }                                        
                                    }                                                                         
                                }
                                compareBapVeriants(response.body[i].data[res][datapoint][ele])                                
                            }
                        };                        
                    }
                }
            }   
        });
    });
});

function compareBapVeriants(refData: any) {
    Bap_scd_file.forEach((element: any) => {                                   
        if (refData['name'] == element['name']) {
            // below values will be change when any changes in BAP variant specs
            let bap_defaultValue_scd: any
            if (element['defaultValue'] == 'false' || element['defaultValue'] == 'N/A') {
                bap_defaultValue_scd = '0'
            }
            else if (element['defaultValue'] == 'true') {
                bap_defaultValue_scd = '1'
            }
            else {
                bap_defaultValue_scd = element['defaultValue']
            }
            assert.deepEqual(Number(bap_defaultValue_scd), refData['bap_default_value'], 'verifying bap default values after import scd file')
            assert.deepEqual(Number(element['variant'].split(':')[0]), refData['bap_variant'], 'verifying bap variant values after import scd file')                                        
        }                                    
    }); 
}

