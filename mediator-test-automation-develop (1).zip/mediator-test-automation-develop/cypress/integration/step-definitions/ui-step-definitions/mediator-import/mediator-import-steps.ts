
import { Given, When, And, Then, After, Before } from 'cypress-cucumber-preprocessor/steps';
import { MediatorSettingImportHelper } from '../../../../support/helpers/mediator-setting-import-helper';
import { FilePath } from '../../../../support/utils/config-utils/file-path';
import { UnitsTable } from '../../../../support/db-helpers/units-table-handler';
import { flatten } from 'flat';
import { LoginPageHelper } from '../../../../support/helpers/login-page-helper';
import { ProjectManagementPageHelper } from '../../../../support/helpers/projectManagement-page-helper';
import { TopologyPageHelper } from '../../../../support/helpers/topology-page-helper';
import { AddDevicePageHelper } from '../../../../support/helpers/add-device-page-helper';
import { DeviceManagementPageHelper } from '../../../../support/helpers/device-management-page-helper';
import { DeviceProfilePageHelper} from '../../../../support/helpers/device-profile-page-helper';
import { WorkspaceTable } from '../../../../support/db-helpers/workspace-table';
import { InstanceTable } from '../../../../support/db-helpers/instance-table';

const setting_import_obj: MediatorSettingImportHelper = new MediatorSettingImportHelper();
const units_db: UnitsTable = new UnitsTable();
const project_managementpage_obj: ProjectManagementPageHelper = new ProjectManagementPageHelper();
const topology_page_obj: TopologyPageHelper = new TopologyPageHelper();
const add_device_obj: AddDevicePageHelper = new AddDevicePageHelper();
const device_management_obj: DeviceManagementPageHelper = new DeviceManagementPageHelper();

// global veriables
let dName: string;
let gdmodelUuid: string;

Before(function () {
    const workspace_db: WorkspaceTable = new WorkspaceTable();
    const instance_db: InstanceTable = new InstanceTable();
    workspace_db.deleteAllWorkSpace();
    instance_db.deleteAllInstances();
    units_db.deleteAllUnits();
});

Given('Launch and login ICT Web application as a user {string}', function (user_type: string) {
    const login_page_obj: LoginPageHelper = new LoginPageHelper();
    const url = Cypress.env('baseUrl')!;
    const credential = Cypress.env(user_type)!;
    login_page_obj.loginToIct(url, credential);
    cy.wait(2000);
});

When('Create one BCU device {string},{string},{string} in project {string}', function (device_name: string, model: string, ver: string, project_name: string) {
    const device_profile_obj: DeviceProfilePageHelper = new DeviceProfilePageHelper()
    project_managementpage_obj.createProject(project_name, 'Test Project Description');
    topology_page_obj.selectAddDevice();
    add_device_obj.addDevice(device_name, device_name, model, ver);
    dName = device_name;
    // get GDSL Version uuid from device profile
    topology_page_obj.goToDeviceView();
    device_profile_obj.getDeviceGdslVersion().then((gdsl_version:any)=>{
        gdmodelUuid = gdsl_version;        
    });
    add_device_obj.close_Device();
    cy.wait(2000);      
});

When('User click on "RTE Settings Import" button', function(){
 //dName= 'SITEULIGNE1BCU1';  
    device_management_obj.clickOnDeviceIconInList(dName);
    device_management_obj.clickOnthreeDotsIcon();
    setting_import_obj.verifySettingImportBtn();
    setting_import_obj.clickOnSettingImportButton();    
});

Then('User select created device and must be able to see "RTE Settings Import" button in device extended menu', function() { 
    device_management_obj.clickOnDeviceIconInList(dName);
    device_management_obj.clickOnthreeDotsIcon();
    setting_import_obj.verifySettingImportBtn();            
});

Then('User must be able to import required .par {string} file from local path', function(file_name: string) {
    setting_import_obj.uploadSettingFile(FilePath.setting_file + file_name);    
});

When('User click on import selection button', function() {
    setting_import_obj.clickOnImportSelection();  
});

When('User click on import selection button and wait', function() {
    setting_import_obj.clickOnImportSelectionAndWait();  
});

Then('User must be able to see process screen provide a view of what will be updated with the current value and the new value from .par file', function() {
    setting_import_obj.verifyMediatorDataGrid();
    setting_import_obj.checkingOverlay();
});

Then('Import error is displayed on the screen', function() {
    setting_import_obj.verifyErrorMessage();    
});

Then('User try to import .txt {string} file', function(file_name: string) {
    setting_import_obj.uploadSettingFile(FilePath.setting_file + file_name);    
});

Then('Next button should be disabled after clicking Import selection button', function() {
    setting_import_obj.clickOnImportSelectionAndWait();
    setting_import_obj.checkNextButton();    
});

Then('Import selection button should be disabled', function () {
    setting_import_obj.verifyImportSelection();
});

Then('User must be able to see process data in table formate', function() {
    setting_import_obj.verifyMediatorDataGrid();
    setting_import_obj.checkingOverlay();
});

When('User select export to excel option from context menu', function() {
    setting_import_obj.exportSettingsInToExcel();     
});

Then('Setting data should be exported in to excel file', function() {   
    cy.verifyDownload(FilePath.excel_file);
});

When('User select export to csv option from context menu', function() {
    setting_import_obj.exportSettingsInToCsv(); 
});

Then('Setting data should be exported in to csv file', function() {   
    cy.verifyDownload(FilePath.csv_file);
});

Then('logOut From Application', function () {
    project_managementpage_obj.logOutICTApp();
});

When('User try to import .par {string} file with on error from local path', function (file_name: string) {
    setting_import_obj.uploadSettingFile(FilePath.setting_file + file_name); 
});

When('User try to import invalid setting .par {string} file from local path', function (file_name: string) {
    setting_import_obj.uploadSettingFile(FilePath.setting_file + file_name); 
});

When('close mediator dialog', function () {
    setting_import_obj.clickCancelButton(); 
});

When('finish mediator setting import', function () {
    setting_import_obj.clickFinishBtn(); 
});

Then('User collect update parameter name and new values and click next button and verify the setting data in application', async function() {
    Promise.all([setting_import_obj.getSettingImportDataTop('id','newValue'), // newValue is grid column name
        setting_import_obj.getSettingImportDataCenter('id','newValue'),
        setting_import_obj.getSettingImportDataBottom('id','newValue')]).then((values) => {
        let data_from_mediator = values.reduce((a, b) => Object.assign(a,b), {});
        setting_import_obj.clickNextButton();        
        
        //below uuid needs to get from ICT application. 
        //let gdmodelUuid: string = '4e7f7964-c65a-4e36-a578-8c5e8726ff51';
        units_db.getDbData(gdmodelUuid).then((uuid: any) => {
            let rec = uuid;
            const target_ins_id: any = Object.values(rec[0]);
            cy.log('first query ' + target_ins_id);

            units_db.getSettingUuidFromUnitsTable(target_ins_id, gdmodelUuid).then((node_uuid: any) => {
                let node_uuid_list = new Map<string, string>();
                node_uuid_list.set('commonConfBlock', node_uuid[0].data.commonConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('functionConfBlock', node_uuid[0].data.functionConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('protectionConfBlock', node_uuid[0].data.protectionConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('genericDataConfBlock', node_uuid[0].data.genericDataConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('inputOutputConfBlock', node_uuid[0].data.inputOutputConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('communicationConfBlock', node_uuid[0].data.communicationConfBlock.split('@')[1].split(' ')[0]);
                node_uuid_list.set('electricalEquipmentConfBlock', node_uuid[0].data.electricalEquipmentConfBlock.split('@')[1].split(' ')[0]);

                node_uuid_list.forEach((value: string, key: string) => {

                    // get the data units table
                    units_db.getSettingDataFromUnitsTable(value).then((data: any) => {
                        const flatten_data: any = flatten(data[0].data);                        
                        for (value in data_from_mediator) {
                            // Returns the value of the first element in the array where predicate is true
                            const findData: any = Object.keys(flatten_data).find(key => key.includes(value));
                            if (findData) {
                                let setting_name = findData.split('.');
                                if (setting_name[setting_name.length - 1] == value) {
                                    // @ts-ignore
                                    cy.softAssert(flatten_data[findData].toString(), data_from_mediator[value].toString(), value + ' - setting value');
                                };
                            };
                        };                        
                    });

                });
                // @ts-ignore
                cy.softAssertAll();

            });
        });
    });
    
});

Then('Verify data shown in mediator dialog as new and old values', async function () {
    setting_import_obj.clickNextButton();
    Promise.all([setting_import_obj.getSettingImportDataFromThreeColTop('id','oldValue','newValue'), // newValue is grid column name
        setting_import_obj.getSettingImportDataFromThreeColCenter('id','oldValue','newValue'),
        setting_import_obj.getSettingImportDataFromThreeColBottom('id','oldValue','newValue')]).then((values) => {
        let old_new_values = values.reduce((a, b) => Object.assign(a,b), {});
        for (let x in old_new_values) {
        let settingVal: any =old_new_values[x].split(':');
        expect(settingVal[0]).to.equals(settingVal[1]);
        }     
    });
        
});

Then('Export setting report data {string} should be same as data shown in mediator dialog', async function (file_path: string) {
    Promise.all([setting_import_obj.getSettingImportDataFromFourColTop('id','oldValue','newValue','status'), // newValue is grid column name
        setting_import_obj.getSettingImportDataFromFourColCenter('id','oldValue','newValue','status'),
        setting_import_obj.getSettingImportDataFromFourColBottom('id','oldValue','newValue','status')]).then((values) => {
        let export_data_from_dialog = values.reduce((a, b) => Object.assign(a,b), {});
        cy.log(export_data_from_dialog);
        //const file_path: string = 'cypress/downloads/export.xlsx'    
        cy.task('parseXlsx', {file_path}).then((jsonData: any) => {
            const exceldata = jsonData[0].data;
            const exceldata_map: any = {};    
            exceldata.forEach(function (arrayData: any , i: any) {
                if(i != 0) {
                    let ex_data = arrayData.toString().split(',');   
                    exceldata_map[ex_data[0]] = ex_data[1] + ':' + ex_data[2] + ':' + ex_data[3];
                }                
            });
            cy.log(exceldata_map);
            assert.equal(Object.keys(export_data_from_dialog).length,Object.keys(exceldata_map).length, 'export report and mediato setting import data length is not equal');

            Object.keys(exceldata_map)                     
            .every(p =>assert.equal(exceldata_map[p],export_data_from_dialog[p], 'export report and mediato setting import data is not equal')
            );         
        });
    }); 
});

When('Click Next button and select export to excel option from context menu after updated ICT settings with .par file data', function() {
    setting_import_obj.clickNextButton();
    setting_import_obj.exportSettingsInToExcel();     
});

When('User select export to CSV option from context menu before update ICT settings with .par file data', function() {
    setting_import_obj.clickNextButton();
    setting_import_obj.exportSettingsInToCsv();     
});

When('Click Next button and select export to CSV option from context menu after updated ICT settings with .par file data', function() {
    setting_import_obj.clickNextButton();
    setting_import_obj.exportSettingsInToCsv();     
});
