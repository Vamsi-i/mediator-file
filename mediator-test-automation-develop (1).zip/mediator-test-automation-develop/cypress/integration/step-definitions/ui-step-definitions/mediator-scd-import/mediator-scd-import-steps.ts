import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';
import { MediatorScdImportHelper } from '../../../../support/helpers/mediator-scd-import-helper';
import { FilePath } from '../../../../support/utils/config-utils/file-path';
import { ProjectManagementPageHelper } from '../../../../support/helpers/projectManagement-page-helper';
import { DeviceManagementPageHelper } from '../../../../support/helpers/device-management-page-helper';
import { parseString } from 'xml2js';
import { WorkspaceTable } from '../../../../support/db-helpers/workspace-table';
import { TopologyPageHelper } from '../../../../support/helpers/topology-page-helper';
import { DeviceSettingsNetworkHelper } from '../../../../support/helpers/device-settings-network-helper';

const scd_import_helper_obj: MediatorScdImportHelper = new MediatorScdImportHelper();
const project_mgmt_helper_obj: ProjectManagementPageHelper = new ProjectManagementPageHelper();
const device_mgmt_helper_obj: DeviceManagementPageHelper = new DeviceManagementPageHelper();
const workspace_DB: WorkspaceTable = new WorkspaceTable();
const topology_obj : TopologyPageHelper = new TopologyPageHelper();
const device_settings_network: DeviceSettingsNetworkHelper = new DeviceSettingsNetworkHelper();

let project_name_scd: string
let geDevices: any [] = [];

Then('User must be able to see "Mediator project plugin" button', function() {
    project_mgmt_helper_obj.checkMediatorProjectImportBtn();
});

When('User click on "Mediator project Import" button', function() {
    project_mgmt_helper_obj.clickMediatorProjectImportButton();   
});

Then('User must be able to import required scd from local path {string}', function(file_name: string) {
    scd_import_helper_obj.uploadScdFile(FilePath.scd_file + file_name);
    scd_import_helper_obj.checkingGeDeviceList();  
});

Then('Verify all GE devices from mediator dialog and scd file which are defined type as BC360 {string} and MU360 {string} in scd file {string}', function(bcu: string, mu: string, file_name: string) {
    let geDevicesFromScd: any [] = [];
    let geDevices: any [] = [];
    let selectedDevicesByDefault: any [] = [];
    geDevices = scd_import_helper_obj.getListOfDevicesFromMediator();       
    selectedDevicesByDefault = scd_import_helper_obj.getSelectedDeviceByDefault();    
    cy.readFile('cypress/fixtures/'+ FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
        parseString(xmldata, function (err: any, data: any) {
            const scl_data: any = Object.values(data);
            const ieds: any = Object.values(scl_data[0].IED);
            ieds.forEach(device => {
                let device_info:any = Object.values(device);
                if (device_info[0].type === bcu || device_info[0].type === mu) {
                    geDevicesFromScd.push(device_info[0].name);
                }
            });        
            assert.deepEqual(geDevices,geDevicesFromScd, 'Comparing GE devices in SCD file and mediator plug-in dialog');       
            assert.equal(geDevicesFromScd.length, selectedDevicesByDefault.length, 'Comparing devices which are selected by default in mediator plug-in dialog');
        });
    });
    scd_import_helper_obj.closeScdImportdia();
});

Then('verify all Thired party devices from mediator dialog and scd file {string}', function(file_name: string) {
    let thirdPartyDevicesFromScd: any [] = [];
    let thirdPartyDevices: any [] = [];
    let unSelectedDevicesByDefault: any [] = [];
    thirdPartyDevices =  scd_import_helper_obj.getListOfThirdPartyDevices();
    unSelectedDevicesByDefault = scd_import_helper_obj.thirdPartyUnselectedDevicesByDefault(); 
    cy.readFile('cypress/fixtures/'+ FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
        parseString(xmldata, function (err: any, data: any) {
            const scl_data: any = Object.values(data);
            const ieds: any = Object.values(scl_data[0].IED);
            ieds.forEach(device => {
                let device_info: any = Object.values(device);                    
                if (device_info[0].type !== 'BC360' && device_info[0].type !== 'MU360') {
                    thirdPartyDevicesFromScd.push(device_info[0].name);
                }
            });
            assert.deepEqual(thirdPartyDevices,thirdPartyDevicesFromScd, 'Comparing third party devices in SCD file and mediator plug-in dialog'); 
            assert.equal(thirdPartyDevicesFromScd.length, unSelectedDevicesByDefault.length,'Comparing third party devices which are unselected by default in mediator plug-in dialog');
        });
    });  
    scd_import_helper_obj.closeScdImportdia();  
});

When('Get all GE devices from mediator import dialog and click import selection button', function () {
    geDevices = scd_import_helper_obj.getListOfDevicesFromMediator();
    scd_import_helper_obj.clickImportSelectionBtn();
    //scd_import_helper_obj.clickOkInError();  // need to remove this step once error got resolved
    //cy.wait(20000);
});

Then('Verify project name after importing scd file {string} through mediator plugin', function(file_name: string) {
    cy.readFile('cypress/fixtures/'+ FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
        parseString(xmldata, function (err: any, data: any) {
            const scl_data: any = Object.values(data);                
            const header_data: any = Object.values(scl_data[0].Header);
            const header: any = header_data.map(header_value => header_value.$);
            const id: string = header.map((header_value: { id: any; }) => header_value.id);
            const ver: string = header.map((header_value: {version: any;}) => header_value.version);
            const rev: string = header.map((header_value: { revision: any}) => header_value.revision)
            project_name_scd = id[0]+ver[0]+rev[0];
            project_mgmt_helper_obj.projectExistedInList(project_name_scd);
        });
    });     

});

When('Open imported project', function () {
    project_mgmt_helper_obj.clickActionCellButton(project_name_scd);
    project_mgmt_helper_obj.openProject();    
});

Then('Verify devices list in ict which are imported from mediator plugin from scd file', function() {
    device_mgmt_helper_obj.getDeviceListInOneProject().then((value: any ) => {
        expect(value).to.deep.equal(geDevices);
    })     
});

Then('Verify AliasTCPIP property for all device instances', function() {
    device_settings_network.verifyAliasTCPIPfield();
});

Then('logOut From Application', function () {
    project_mgmt_helper_obj.logOutICTApp();    
});

Then('delete imported project from ict appliation', function () {
    workspace_DB.deleteAllWorkSpace();
});

When('Select one device {string} and click on send button', function (device: string) {
    device_mgmt_helper_obj.clickOnDeviceIconInList(device);
    topology_obj.clickOnSend();    
});

When('Navigate to IEC61850 view in ICT for a {string}', function(device_name: string) {
    device_mgmt_helper_obj.goToIEC61850(device_name);
});

Then('Verify all Third party devices from {string} file and IEC61850 section', function(file_name: string) {
    let thirdPartyDevicesFromScd: any [] = [];
    let thirdPartyDevicesInIEC61850: any [] = [];
    thirdPartyDevicesInIEC61850 =  device_mgmt_helper_obj.getThirdPartyDevicesInIEC61850();
    cy.readFile('cypress/fixtures/'+ FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
        parseString(xmldata, function (err: any, data: any) {
            const scl_data: any = Object.values(data);
            const ieds: any = Object.values(scl_data[0].IED);
            ieds.forEach(device => {
                let device_info: any = Object.values(device);                    
                if (device_info[0].type !== 'BC360' && device_info[0].type !== 'MU360') {
                    thirdPartyDevicesFromScd.push(device_info[0].name);
                }
            });
            assert.deepEqual(thirdPartyDevicesInIEC61850,thirdPartyDevicesFromScd, 'Comparing third party devices in SCD file and on IEC61850 screen'); 
            
        });
    });  
});

Then('Verify generation logs and logs should not have any errors', function () {   
    Promise.any([topology_obj.getDetailsFromGenerationTable()]).then((logs) => {
        expect(logs[0]).to.eq('Generating CID file');
        expect(logs[1]).to.include('Successfully generated CID file');
        expect(logs[2]).to.eq('Generation request sent');   
        expect(logs[3]).to.include('Observing generation');
        expect(logs[4]).to.include('Ack');
        expect(logs[5]).to.include('Finished');
        expect(logs[6]).to.include('Output directory');   
    });  
      
});