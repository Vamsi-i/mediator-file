import { Given, When, And, Then, After, Before } from 'cypress-cucumber-preprocessor/steps';
import { MediatorScdImportHelper } from '../../../../support/helpers/mediator-scd-import-helper';
import { ProjectManagementPageHelper } from '../../../../support/helpers/projectManagement-page-helper';
import { DeviceManagementPageHelper } from '../../../../support/helpers/device-management-page-helper';
import { WorkspaceTable } from '../../../../support/db-helpers/workspace-table';
import { DeviceSettingsNetworkHelper } from '../../../../support/helpers/device-settings-network-helper';
import { FilePath } from '../../../../support/utils/config-utils/file-path';
import { JsonHandler } from '../../../../support/utils/file-handler-utils/json-handler';
import { parseString } from 'xml2js';
import { DeviceSettingsUserDataHelper} from '../../../../support/helpers/device-settings-userdata-page-helper';

let client_input_dict ={};
let client_input_dict_exp ={};
let function_dict = {};
let extref_items: any = []


const scd_import_helper_obj: MediatorScdImportHelper = new MediatorScdImportHelper();
const project_mnt_page_helper: ProjectManagementPageHelper = new ProjectManagementPageHelper();
const device_mnt_page_helper: DeviceManagementPageHelper = new DeviceManagementPageHelper();
const workspace_DB: WorkspaceTable = new WorkspaceTable();
const device_settings_network: DeviceSettingsNetworkHelper = new DeviceSettingsNetworkHelper();
const device_settings_userdata: DeviceSettingsUserDataHelper = new DeviceSettingsUserDataHelper();


When('User navigate to {string} function screen in settings page for {string}', function (function_name: string, device_name:string) {
    device_mnt_page_helper.goToDeviceView(device_name);
    device_settings_network.goToSettingsSubFunction(function_name);
});

When('User navigate to {string} function screen in {string} settings page', function (function_name: string, device_name:string) {
  device_mnt_page_helper.goToDeviceView(device_name);
  cy.wait(2000) // this wait is required for setting load
  device_settings_network.goToSettingsSubFunction(function_name);
  cy.wait(3000) // this wait is required for setting load
  //cy.log('step page' + device_settings_userdata.getListOfExtRefDatapoints());
  extref_items = device_settings_userdata.getListOfExtRefDatapoints();
});

When('User Click on Inputs button', function() {
    device_settings_network.goToInputs();
});

When('User navigate to the {string} of ADD function in ICT UI', function(datapoint_name: string) {
    device_settings_network.goToDataPoint(datapoint_name);
    
})
Then('Verify the array of datapoints for {string} in ICT UI', function() {
  device_settings_network.getListOfDatapoints().then(ele => {
    expect(ele.length).is.greaterThan(1);
  });
});
Then('Verify the array of datapoints are limited to maximum of 10 values', function() {
  device_settings_network.getListOfDatapoints().then(ele => {
    expect(ele.length).is.equal(10);
  });
});
Then('Verify user is able to select an Inref {string} datapoint out of array of datapoints', function(Inref_value: string) {
  device_settings_network.selectADataPoint(Inref_value);
});

Then('Verify the ExtRef values in ICT UI from the file {string},{string}', function(file_name: string, data_point:string) {
  cy.readFile('cypress/fixtures/' + FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
    parseString(xmldata, function (err: any, results: any) {
      let extref_array: any = [];        
      const ld_count = Object.keys(results.SCL.IED[1].AccessPoint[0].Server[0].LDevice).length;
      //cy.log(ld_count)
      for (let i = 0; i < ld_count; i++) {
        const ldeviceinst: any = results.SCL.IED[1].AccessPoint[0].Server[0].LDevice[i].$['inst'];
        if (ldeviceinst == data_point) {
          let extrefs: any = results.SCL.IED[1].AccessPoint[0].Server[0].LDevice[i].LN0[0].Inputs[0].ExtRef
          extrefs.forEach((element: string) => {
            //cy.log(element)
            for (let [key, value] of Object.entries(element)) {
              let extref_obj = element[key] 
              if (Object.keys(extref_obj).length > 5) {
                extref_array.push(extref_obj['iedName'] + '/' + extref_obj['ldInst'] + '/' +
                extref_obj['prefix'] + extref_obj['lnClass'] + extref_obj['lnInst'] +
                '$' + extref_obj['doName'] + '$' + extref_obj['daName'])                
              }              
            }            
          });
        }
        
      }      
      extref_array.forEach(eleme => {
        expect(extref_items).to.include(eleme);
      });
    });
  });
})


// When('Verify the Inref values in ICT UI from the file {string}', function(file_name: string) {
//   JsonHandler.readJson(FilePath.path_inrefmapping_file).then(function (requestBody) {    
//     for(let no_fun=0;no_fun<requestBody.length;no_fun++)
//       function_dict[requestBody[no_fun].id] = 'data.'+requestBody[no_fun].unit+'.'+requestBody[no_fun].elementName+'.'+requestBody[no_fun].commonClassId
//       //cy.log(requestBody);
//   });
//   const cid_path = FilePath.path_storage + 'd94e8559-7e39-409f-b8f5-f29a1793b871' + '/configuration/unzip/BC360/BC360/BC360.cid'
//   cy.readFile('cypress/fixtures/'+ FilePath.scd_file + file_name, 'utf-8').then(xmldata => {
//     parseString(xmldata, function (err: any, results: any) {
//       let ldevice_array: any = [];
//       let doi_array: any = [];
//       //let nb_dai:any;
//       const nb_items = Object.keys(results.SCL.IED[0].AccessPoint[0].Server[0].LDevice).length;
//       //cy.log(results.SCL.IED[0].AccessPoint[0].Server[0].LDevice);
//       JsonHandler.readJson(FilePath.path_inrefmapping_file).then(function (requestBody) {
//         cy.log(requestBody.length);
//         for (let i = 0; i < nb_items; i++) {
//           const ldeviceinst: any = results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[i].$['inst'];
//           ldevice_array.push(ldeviceinst);
//         }
        
//         for(let j = 0; j<requestBody.length;j++){
//           let ldevice = (requestBody[j].id).split('_')
//           ldevice=ldevice[0];
//           const instldevice = ldevice_array.indexOf(ldevice);
//           //cy.log("device",ldevice);
          
//           if(instldevice>=0)
//           {
//             doi_array = [];
//             const nb_doi = results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI.length;
//             //cy.log("no of doi",ldevice,nb_doi);
//             for (let doi = 0; doi < nb_doi; doi++) {
//               const name_doi_name = results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[doi].$['name'];
//               //if(name_doi_name.includes('InRef'))
//               doi_array.push(name_doi_name);
//             }
//           }
          
//           for(let k = 0 ;k<doi_array.length;k++){
//             const nb_dai = results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[k].DAI.length;
//             TestDAI(nb_dai,k,results,instldevice,requestBody[j],doi_array,ldevice);
//           }
//         }
//       });
//     });
//   });

// })

// function TestDAI(nb_dai,k,results,instldevice,inref_details,doi_array,ldevice){
//   let dai_ref_index;
//   let counter = nb_dai;
//   while (counter>0) {
//     counter = counter-1;
//     if(results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[k].DAI[counter].$['name']=='setSrcRef')
//     {
//       dai_ref_index = counter;
//     }
//   }
//   let counter1 = nb_dai;
//   while (counter1>0) {
//     let sce_id_exp;
//     counter1 = counter1-1;
//     if(results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[k].DAI[counter1].$['name']=='purpose'){
//       if((results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[k].DAI[counter1].Val[0]).includes(inref_details.id)==true)
//       {
//         if(function_dict[ldevice]!=null)
//         {
//           const fun_str = function_dict[ldevice].split('.');
//           let fun_str_val = '';
//           for(let i= 0;i<fun_str.length-1;i++)
//           {
//             fun_str_val = fun_str_val+ fun_str[i]+'.';
//           }
//           const saddr_exp = results.SCL.IED[0].AccessPoint[0].Server[0].LDevice[instldevice].LN0[0].DOI[k].DAI[dai_ref_index].$['sAddr'];
//           const common_class_id = inref_details.commonClassId; 
//           const iec_addr = ldevice+'/LLN0$SP$'+doi_array[k]+'$setSrcRef';
//           sce_id_exp = fun_str_val + inref_details.elementName + '.' + fun_str[fun_str.length-1]+'.'+saddr_exp;
//           client_input_dict_exp[sce_id_exp+'/'+'ucaid'] = saddr_exp;
//           client_input_dict_exp[sce_id_exp+'/'+'commonclass'] = common_class_id;
//           client_input_dict_exp[sce_id_exp+'/'+'iecaddr'] = iec_addr;
//           //cy.log(sce_id_exp);
//         }
        
//       } 
//     }
//   }
// }