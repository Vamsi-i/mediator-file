import { After, Before } from "cypress-cucumber-preprocessor/steps";
import { UIHandler } from "../../support/utils/ui-utils/cypress-util";

Before(function () {
    UIHandler.deleteAllCookies();
});

After(function () {
    
});