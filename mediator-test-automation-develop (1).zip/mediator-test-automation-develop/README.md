# GDMTestAutomation

TO RUN THE TEST IN LOCAL:
------------------------
Prequisite: 
1. Install NodeJS
3. Run command 'npm install' from command prompt

TO RUN THE TEST FROM CYPRESS RUNNER:
------------------------------------
1. Type command 'npm run cy:open'
2. Set the browser as 'Electron 93'
3. Click on the test and run

Note: Test does not execute from Chrome and firefox through the test runner.

EXECUTE THE TEST:
-----------------
Xray:
To run the test using xray: Set the "Xray: Y" in "cypress/fixtures/config-data/run-config.yml"
Note: Donot change the ReleaseTestPlan in the cypress/fixtures/config-data/run-config.yml file

i. Xray with "Enter Test Execution Id" Option.
            Set "Test:" in "cypress/fixtures/config-data/run-config.yml" as "Enter Test Execution Id" and  Provide the "TestExecutionId: #JiraTestExecutionTicketNumber" in "cypress/fixtures/config-data/run-config.yml" and In the terminal, run the command "npm run xray"

ii. Xray with "Execute Tests with ANY status from Test Plan" Option.
            Set "Test:" in "cypress/fixtures/config-data/run-config.yml" as "Execute Tests with ANY status from Test Plan" and  Provide the "ReleaseTestPlan: #JiraTestPlanTicketNumber" in "cypress/fixtures/config-data/run-config.yml" and In the terminal, run the command "npm run xray"

iii. Xray with "Xray- Execute Tests with PASS status from Test Plan" Option.
            Set "Test:" in "cypress/fixtures/config-data/run-config.yml" as "Xray- Execute Tests with PASS status from Test Plan" and Provide the "ReleaseTestPlan: #JiraTestPlanTicketNumber" in "cypress/fixtures/config-data/run-config.yml" and In the terminal, run the command "npm run xray"

iv. Xray with "Xray- Execute Tests with TODO status from Test Plan" Option.
            Set "Test:" in "cypress/fixtures/config-data/run-config.yml" as "Xray- Execute Tests with TODO status from Test Plan" and Provide the "ReleaseTestPlan: #JiraTestPlanTicketNumber" in "cypress/fixtures/config-data/run-config.yml" and In the terminal, run the command "npm run xray"

v. Xray with "Xray- Execute Tests with FAIL status from Test Plan" Option.
            Set "Test:" in "cypress/fixtures/config-data/run-config.yml" as "Xray- Execute Tests with FAIL status from Test Plan" and Provide the "ReleaseTestPlan: #JiraTestPlanTicketNumber" in "cypress/fixtures/config-data/run-config.yml" and In the terminal, run the command "npm run xray"

API:
1. Xray not configured for this option:
    Set the "Xray: N" in "cypress/fixtures/config-data/run-config.yml"
2. In the terminal, run the command "npm run api"

All Test:
1. Xray not configured for this option:
    Set the "Xray: N" in "cypress/fixtures/config-data/run-config.yml"
2. In the terminal, run the command "npm run all"

UI Test:
1. Xray not configured for this option:
    Set the "Xray: N" in "cypress/fixtures/config-data/run-config.yml"
2. In the terminal, run the command "npm run ui"

Regression Test: Test with Tag '@regression' is picked for execution
1. Xray not configured for this option:
    Set the "Xray: N" in "cypress/fixtures/config-data/run-config.yml"
2. In the terminal, run the command "npm run regression"

TagExecution:
1. Add the tag that you want to execute and run the below command
./node_modules/.bin/cypress-tags run -e TAGS=@tagToRun

REPORT:
------
1. On using xray option, report will be attached to the Jira ticket number provided
2. By default, report will be generated in the "cypress/report" folder


TO RUN THE TEST IN JENKINS:
--------------------------
Url: https://i.ci.build.ge.com/u7io4cet/ci/job/gdm-test-automation/job/develop/build?delay=0sec

Code to be pushed into GIT.
Options Available in Jenkins:


        i. TEST: 
            All Test = Run all the test available in the test suite
            API Test = Run all the api test available in the test suite
            UI Test = Runs all the UI test available in the test suite
            Regression Test = Runs all the UI test available in the test suite
            Smoke Test = Runs all the Smoke test available in the test suite
            TagExecution = Runs the test with the tag provided the user. Provide "TAGEXECUTION" with the tag name. eg : "@GADM-982"
            Xray- Enter Test Execution Id = Runs all the test under a test execution given in Jenkins Parameter "TESTEXECUTION"
            Xray- Execute Tests with FAIL status from Test Plan = Runs all the failed test alone under the ReleaseTestPlan id configured in run-config.yml
            Xray- Execute Tests with PASS status from Test Plan = Runs all the Passed test alone under the ReleaseTestPlan id configured in run-config.yml
            Xray- Execute Tests with TODO status from Test Plan = Runs all the newly added test(with TODO status) under a test plan (ReleaseTestPlan id )configured in run-config.yml
            Xray- Execute Tests with ANY status from Test Plan = Runs all the test under the ReleaseTestPlan id configured in run-config.yml

        ii. TESTEXECUTION : Used to provide test execution id when the tester wants to execute the tests under the test execution.This applies with option "TEST:Xray- Enter Test Execution Id"

        iii. TAGEXECUTION : Used to provide tag id when the tester wants to execute the tests under the "TEST" with "TagExecution".

        iv. ENVIRONMENT: Allows testers to provide the environment name.
                Environment Available
                    a. Dev  - Contains the latest Development code
                    b. Staging
                    c. Docker - Allows the testers/Developers to run the test with different version of the development code. Works with Jenkins Parameter "WEBAPP", "RESOURCES", "MAINTENANCE", "AGENT", "FILEHANDLER". These are the options configured which downloads different images of docker compose. Provide the image name in the fields "WEBAPP", "RESOURCES", "MAINTENANCE", "AGENT", "FILEHANDLER" and run the tests.

TO NAVIGATE TO STEP DEFINITIONS FROM FEATURE FILE:
--------------------------------------------------
1. Install "Cucumber (Gherkin) Full Support" plugin 
2. This step will be required for new folder configration : Include the feature and step definition file names in the ".vscode/settings.json"
    "cucumberautocomplete.steps": [
        "path of step definition"
    ],
    "cucumberautocomplete.syncfeatures": "path of feature file",

Lint check:
------------
1. Use prettier formatter- Plugin "Prettier - Code formatter"
2. Run "npm run linter" before checking in the code and fix the errors.

Procedure to push code into Repository:
--------------------------------------
1. Install "Jira and Bitbucket (Official)"
2. In Authentication, click "Login to Jira Cloud" and provide baseurl as "https://stamp.gs.ec.ge.com/jira"
3. Enable "Context Path" and provide "context path" as "/jira"
4. Provide "Username" and "Password"
5. Click save site
6. Under "Jira Issues Explorer" 
7. Edit and Add JQL query. 
    Eg Filter:project = GADM AND resolution = Unresolved AND assignee = currentUser() AND issuetype in( Story, Sub-task, Defect) ORDER BY priority DESC, updated DESC  
8. Under "Atlassian" tab, search for the issue and click on "start work"
9. It creates a branch and push the code in the branch created
10. The task moves into "In Review" after jenkins validation
11. Once pull request is approved and merged, the task moves to "Done"

Note:  @jenkins tag should be added to the test to run them as part of 'Validation on Automated test' stage in jenkins